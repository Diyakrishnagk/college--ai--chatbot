import sys, traceback

print("="*50)
print("CHECKING ALL APP MODULES")
print("="*50)

tests = [
    ("config",          "from app.config import settings"),
    ("database",        "from app.models.database import Base, User, Document, Conversation, Message, create_tables"),
    ("auth_service",    "from app.services.auth_service import hash_password, verify_password, create_access_token"),
    ("embedding_svc",   "from app.services.embedding_service import generate_embedding"),
    ("chroma_svc",      "from app.services.chroma_service import get_collection"),
    ("ollama_svc",      "from app.services.ollama_service import check_ollama_health"),
    ("citation_svc",    "from app.services.citation_service import extract_citations, build_context_from_chunks"),
    ("document_svc",    "from app.services.document_service import validate_file, safe_filename"),
    ("rag_service",     "from app.services.rag_service import answer_question"),
    ("pdf_loader",      "from app.utils.pdf_loader import extract_text_from_pdf"),
    ("docx_loader",     "from app.utils.docx_loader import extract_text_from_docx"),
    ("txt_loader",      "from app.utils.text_loader import extract_text_from_txt"),
    ("text_chunker",    "from app.utils.text_chunker import split_text_into_chunks, create_chunks_with_metadata"),
    ("api.auth",        "from app.api.auth import router"),
    ("api.chat",        "from app.api.chat import router"),
    ("api.documents",   "from app.api.documents import router"),
    ("api.analytics",   "from app.api.analytics import router"),
    ("api.users",       "from app.api.users import router"),
    ("main app",        "from app.main import app"),
]

failed = []
for name, stmt in tests:
    try:
        exec(stmt)
        print(f"  OK   {name}")
    except Exception as e:
        print(f"  FAIL {name}: {e}")
        failed.append((name, str(e)))

print()
if failed:
    print(f"FAILED: {len(failed)} module(s)")
    for name, err in failed:
        print(f"  - {name}: {err}")
    sys.exit(1)
else:
    print(f"ALL {len(tests)} MODULES OK")
