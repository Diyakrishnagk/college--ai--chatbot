@echo off
title College AI Frontend
cd /d "%~dp0frontend"

echo ================================================
echo  College AI Assistant - Frontend Setup and Start
echo ================================================
echo.

:: Check if node_modules exists
if not exist "node_modules" (
    echo [1/2] Installing npm packages (first time only)...
    npm install
    if errorlevel 1 (
        echo ERROR: npm install failed. Is Node.js installed?
        pause
        exit /b 1
    )
) else (
    echo [1/2] npm packages already installed.
)

:: Create .env if missing
if not exist ".env" (
    echo Creating frontend .env...
    copy .env.example .env
)

echo [2/2] Starting frontend development server...
echo.
echo  Frontend: http://localhost:5173
echo.
echo  Press Ctrl+C to stop.
echo.

npm run dev

pause
