from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks
from pydantic import BaseModel
from sqlalchemy.orm import Session
from typing import Optional, List
import json
from datetime import datetime

from app.models.database import get_db, Conversation, Message, Feedback, User
from app.services.auth_service import get_current_user
from app.services.rag_service import answer_question
from app.services.ollama_service import check_ollama_health

router = APIRouter(prefix="/chat", tags=["Chat"])


class ChatRequest(BaseModel):
    question: str
    conversation_id: Optional[str] = None


class FeedbackRequest(BaseModel):
    message_id: str
    rating: int  # 1 or -1
    comment: Optional[str] = None


class RenameConversationRequest(BaseModel):
    title: str


@router.post("")
async def chat(
    req: ChatRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if not req.question.strip():
        raise HTTPException(status_code=400, detail="Question cannot be empty")

    try:
        result = await answer_question(
            db=db,
            question=req.question,
            conversation_id=req.conversation_id,
            user_id=current_user.id
        )
        return result
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")


@router.get("/ollama-status")
async def ollama_status():
    """Check if Ollama is running and the configured model is available."""
    return await check_ollama_health()


@router.get("/conversations")
def get_conversations(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    conversations = db.query(Conversation).filter(
        Conversation.user_id == current_user.id
    ).order_by(Conversation.updated_at.desc()).all()

    result = []
    for conv in conversations:
        msg_count = db.query(Message).filter(Message.conversation_id == conv.id).count()
        result.append({
            "id": conv.id,
            "title": conv.title,
            "message_count": msg_count,
            "created_at": conv.created_at.isoformat(),
            "updated_at": conv.updated_at.isoformat()
        })
    return result


@router.get("/conversations/{conversation_id}")
def get_conversation(
    conversation_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    conversation = db.query(Conversation).filter(
        Conversation.id == conversation_id,
        Conversation.user_id == current_user.id
    ).first()
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")

    messages = db.query(Message).filter(
        Message.conversation_id == conversation_id
    ).order_by(Message.created_at).all()

    msgs = []
    for m in messages:
        sources = []
        if m.sources:
            try:
                sources = json.loads(m.sources)
            except Exception:
                pass
        msgs.append({
            "id": m.id,
            "role": m.role,
            "content": m.content,
            "sources": sources,
            "created_at": m.created_at.isoformat()
        })

    return {
        "id": conversation.id,
        "title": conversation.title,
        "messages": msgs,
        "created_at": conversation.created_at.isoformat(),
        "updated_at": conversation.updated_at.isoformat()
    }


@router.patch("/conversations/{conversation_id}")
def rename_conversation(
    conversation_id: str,
    req: RenameConversationRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    conversation = db.query(Conversation).filter(
        Conversation.id == conversation_id,
        Conversation.user_id == current_user.id
    ).first()
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")

    conversation.title = req.title[:100]
    db.commit()
    return {"message": "Conversation renamed", "title": conversation.title}


@router.delete("/conversations/{conversation_id}")
def delete_conversation(
    conversation_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    conversation = db.query(Conversation).filter(
        Conversation.id == conversation_id,
        Conversation.user_id == current_user.id
    ).first()
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")

    db.delete(conversation)
    db.commit()
    return {"message": "Conversation deleted"}


@router.post("/feedback")
def submit_feedback(
    req: FeedbackRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if req.rating not in [1, -1]:
        raise HTTPException(status_code=400, detail="Rating must be 1 (thumbs up) or -1 (thumbs down)")

    message = db.query(Message).filter(Message.id == req.message_id).first()
    if not message:
        raise HTTPException(status_code=404, detail="Message not found")

    # Check if user already gave feedback
    existing = db.query(Feedback).filter(
        Feedback.message_id == req.message_id,
        Feedback.user_id == current_user.id
    ).first()

    if existing:
        existing.rating = req.rating
        existing.comment = req.comment
    else:
        feedback = Feedback(
            message_id=req.message_id,
            user_id=current_user.id,
            rating=req.rating,
            comment=req.comment
        )
        db.add(feedback)

    db.commit()
    return {"message": "Feedback recorded"}
