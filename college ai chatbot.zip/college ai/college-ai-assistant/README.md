# AI-Powered College Assistant Chatbot

A production-style full-stack web application that enables students to ask natural-language questions about college documents using **Retrieval-Augmented Generation (RAG)**, local LLMs via **Ollama**, and **ChromaDB** vector storage.

---

## Features

- **Document Intelligence** — Upload PDFs, DOCX, and TXT files; auto-extract text, chunk, and embed
- **Semantic Search** — ChromaDB stores embeddings for fast similarity search
- **Local LLM** — Ollama runs llama3.2 / mistral / phi3 / gemma entirely offline
- **Hallucination Protection** — LLM is instructed to answer ONLY from retrieved context
- **Source Citations** — Every answer cites the document name and page number
- **Conversation History** — Persistent, rename-able, deletable conversation threads
- **Role-Based Auth** — Student and Admin roles with JWT authentication
- **Admin Panel** — Upload, manage, re-index documents; view analytics
- **Student Dashboard** — Quick actions, recent chats, document browser
- **Analytics** — Questions over time, document stats, user feedback

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, Tailwind CSS, React Router, Axios, Recharts |
| Backend | Python 3.11+, FastAPI, Uvicorn, SQLAlchemy |
| Embeddings | Sentence Transformers (`all-MiniLM-L6-v2`) |
| Vector DB | ChromaDB (persistent, local) |
| Local LLM | Ollama (llama3.2 / mistral / phi3 / gemma) |
| Auth | JWT (python-jose) + bcrypt |
| Database | SQLite |
| PDF | PyMuPDF (fitz) |
| DOCX | python-docx |

---

## Architecture

```
React Frontend (Vite + Tailwind)
         |
         v
FastAPI Backend (Python)
         |
    +---------+---------+
    |                   |
    v                   v
RAG Pipeline         SQLite DB
    |                (users, docs,
    |              conversations, messages)
    +----------+----------+
    |                     |
    v                     v
Sentence Transformers  ChromaDB
(local embeddings)  (vector storage)
    |
    v
Relevant Chunks
    |
    v
Ollama Local LLM
(llama3.2 / mistral)
    |
    v
Answer + Citations
    |
    v
React Chat Interface
```

---

## Folder Structure

```
college-ai-assistant/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI app + startup
│   │   ├── config.py            # Settings from .env
│   │   ├── api/
│   │   │   ├── auth.py          # /api/auth/*
│   │   │   ├── chat.py          # /api/chat/*
│   │   │   ├── documents.py     # /api/documents/*
│   │   │   ├── analytics.py     # /api/analytics/*
│   │   │   └── users.py         # /api/users/*
│   │   ├── models/
│   │   │   └── database.py      # SQLAlchemy models + get_db
│   │   ├── services/
│   │   │   ├── auth_service.py      # JWT, password hashing
│   │   │   ├── rag_service.py       # Full RAG pipeline
│   │   │   ├── document_service.py  # Upload, process, reindex
│   │   │   ├── embedding_service.py # Sentence Transformers
│   │   │   ├── chroma_service.py    # ChromaDB operations
│   │   │   ├── ollama_service.py    # Ollama API client
│   │   │   └── citation_service.py  # Context & citations
│   │   └── utils/
│   │       ├── pdf_loader.py    # PyMuPDF text extraction
│   │       ├── docx_loader.py   # python-docx extraction
│   │       ├── text_loader.py   # Plain text reading
│   │       └── text_chunker.py  # Chunking with overlap
│   ├── data/
│   │   ├── uploads/             # Uploaded document files
│   │   └── chroma/              # ChromaDB persistent storage
│   ├── tests/
│   │   └── test_main.py         # Pytest test suite
│   ├── requirements.txt
│   └── .env.example
│
├── frontend/
│   ├── src/
│   │   ├── App.jsx              # Routes + auth guards
│   │   ├── main.jsx             # Entry point
│   │   ├── context/
│   │   │   └── AuthContext.jsx  # Auth state
│   │   ├── services/
│   │   │   └── api.js           # Axios instance
│   │   ├── layouts/
│   │   │   ├── StudentLayout.jsx
│   │   │   └── AdminLayout.jsx
│   │   └── pages/
│   │       ├── LoginPage.jsx
│   │       ├── RegisterPage.jsx
│   │       ├── student/
│   │       │   ├── Dashboard.jsx
│   │       │   ├── ChatPage.jsx
│   │       │   ├── DocumentsPage.jsx
│   │       │   └── ProfilePage.jsx
│   │       └── admin/
│   │           ├── AdminDashboard.jsx
│   │           ├── UploadPage.jsx
│   │           ├── ManageDocumentsPage.jsx
│   │           ├── AnalyticsPage.jsx
│   │           ├── UsersPage.jsx
│   │           └── SettingsPage.jsx
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
│
└── README.md
```

---

## Requirements

- **Python 3.11+**
- **Node.js 18+** and **npm**
- **Ollama** (free, local, open-source)
- Windows 10/11 (PowerShell or CMD)
- ~4GB RAM minimum (8GB+ recommended for LLM)

---

## Step 1 — Install Ollama

1. Download from: https://ollama.com/download
2. Install and run Ollama
3. Pull a model (choose one):

```powershell
# Recommended (fast, good quality)
ollama pull llama3.2

# Alternatives
ollama pull mistral
ollama pull phi3
ollama pull gemma
```

4. Start Ollama server (usually auto-starts, but you can also run):
```powershell
ollama serve
```

---

## Step 2 — Backend Setup

Open PowerShell and run:

```powershell
cd college-ai-assistant\backend

# Create virtual environment
python -m venv .venv

# Activate (PowerShell)
.venv\Scripts\Activate.ps1

# If you get an execution policy error, use this instead:
# cmd.exe /c ".venv\Scripts\activate && pip install -r requirements.txt"

# Or set policy temporarily:
# Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Install dependencies
pip install -r requirements.txt

# Copy environment file
copy .env.example .env
```

Edit `backend/.env` if you want to change the Ollama model:
```
OLLAMA_MODEL=llama3.2
```

---

## Step 3 — Frontend Setup

Open a new PowerShell window:

```powershell
cd college-ai-assistant\frontend

# Install dependencies
npm install

# If npm.ps1 execution policy error:
# cmd.exe /c "npm install"

# Copy environment file
copy .env.example .env
```

---

## Step 4 — Run the Application

### Terminal 1 — Start Backend

```powershell
cd college-ai-assistant\backend
.venv\Scripts\Activate.ps1
uvicorn app.main:app --reload --port 8000
```

If activation fails in PowerShell:
```cmd
cd college-ai-assistant\backend
.venv\Scripts\activate && uvicorn app.main:app --reload --port 8000
```

### Terminal 2 — Start Frontend

```powershell
cd college-ai-assistant\frontend
npm run dev

# If execution policy error:
# cmd.exe /c "npm run dev"
# Or: npx.cmd vite
```

### Access the Application

| URL | Description |
|-----|-------------|
| http://localhost:5173 | Frontend (React) |
| http://localhost:8000/docs | Backend API docs (Swagger) |
| http://localhost:8000/api/health | Health check |

---

## Default Login Credentials

A default admin account is automatically created on first startup:

| Field | Value |
|-------|-------|
| Email | admin@college.edu |
| Password | admin123 |
| Role | Admin |

**Change the password after first login!**

---

## Using the Application

### As Admin

1. Login at http://localhost:5173/login with `admin@college.edu` / `admin123`
2. You will be redirected to `/admin`
3. Go to **Upload Documents** → drag-drop or select a PDF/DOCX/TXT file
4. Select a category (Academic, Exams, etc.)
5. Click **Upload & Process** — the system will extract text, chunk it, generate embeddings, and store in ChromaDB
6. Go to **Manage Documents** to see status. Wait for status `ready`.

### As Student

1. Register a new account at http://localhost:5173/register
2. Login → you'll be redirected to `/dashboard`
3. Click **Chat** or use a quick action
4. Type a question like: *"What is the minimum attendance required for exams?"*
5. The AI searches ChromaDB, retrieves relevant chunks, sends to Ollama, and returns an answer with citations

---

## Environment Variables

### Backend (`backend/.env`)

| Variable | Default | Description |
|----------|---------|-------------|
| `OLLAMA_BASE_URL` | `http://localhost:11434` | Ollama server URL |
| `OLLAMA_MODEL` | `llama3.2` | LLM model name |
| `OLLAMA_TIMEOUT` | `120` | Request timeout (seconds) |
| `EMBEDDING_MODEL` | `all-MiniLM-L6-v2` | Sentence Transformer model |
| `TOP_K_RESULTS` | `5` | Number of chunks to retrieve |
| `SIMILARITY_THRESHOLD` | `0.35` | Minimum relevance score |
| `CHUNK_SIZE` | `800` | Characters per chunk |
| `CHUNK_OVERLAP` | `150` | Overlap between chunks |
| `MAX_FILE_SIZE_MB` | `20` | Maximum upload size |
| `JWT_SECRET_KEY` | (change this!) | JWT signing key |

### Frontend (`frontend/.env`)

| Variable | Default | Description |
|----------|---------|-------------|
| `VITE_API_BASE_URL` | `http://localhost:8000/api` | Backend API base URL |

---

## API Documentation

FastAPI auto-generates interactive docs at:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### Key Endpoints

```
POST /api/auth/register       Register new user
POST /api/auth/login          Login
GET  /api/auth/me             Get current user

POST /api/chat                Send message (RAG Q&A)
GET  /api/chat/conversations  List conversations
GET  /api/chat/conversations/{id}  Get messages
DELETE /api/chat/conversations/{id}
POST /api/chat/feedback       Submit thumbs up/down

POST /api/documents/upload    Upload document (Admin)
GET  /api/documents           List documents
DELETE /api/documents/{id}    Delete document (Admin)
POST /api/documents/{id}/reindex  Re-index (Admin)

GET  /api/analytics/overview  Dashboard stats (Admin)
GET  /api/analytics/questions Questions over time (Admin)
GET  /api/analytics/documents Document stats (Admin)

GET  /api/users               List users (Admin)
DELETE /api/users/{id}        Delete user (Admin)
```

---

## Running Tests

```powershell
cd college-ai-assistant\backend
.venv\Scripts\Activate.ps1
pip install pytest httpx

python -m pytest tests/ -v
```

Tests cover:
- PDF, DOCX, TXT text extraction
- Text chunking and cleaning
- Embedding generation
- File validation
- Citation extraction
- Password hashing
- JWT tokens
- API endpoints (register, login, auth, documents)

---

## Troubleshooting

### PowerShell Execution Policy Error
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```
Or use CMD instead of PowerShell.

### Ollama Not Running
```
Error: "Ollama is not running"
```
Fix: Run `ollama serve` in a terminal, or check that Ollama is installed.

### Model Not Found
```
Error: "Model not available"
```
Fix: Run `ollama pull llama3.2` (or your configured model).

### Slow Responses
The first request loads the model into RAM. Subsequent requests are faster.
Use a smaller model (`phi3`) on limited hardware.

### ChromaDB Error on Startup
Delete the `backend/data/chroma/` directory and restart. ChromaDB will rebuild.

### Port Already In Use
```powershell
# Kill process on port 8000
netstat -ano | findstr :8000
taskkill /PID <PID> /F
```

### Frontend Can't Connect to Backend
Ensure backend is running on port 8000.
Check `frontend/.env` has `VITE_API_BASE_URL=http://localhost:8000/api`

### Embedding Model Download (First Run)
On first startup, Sentence Transformers will download `all-MiniLM-L6-v2` (~90MB).
This requires internet access on first run only.

---

## Future Improvements

- [ ] Document preview / inline viewer
- [ ] Multi-language support
- [ ] OCR for scanned PDFs (using pytesseract)
- [ ] Streaming LLM responses (SSE)
- [ ] Semantic re-ranking of retrieved chunks
- [ ] Role-based document access control
- [ ] Scheduled re-indexing
- [ ] Export conversation as PDF
- [ ] Docker Compose deployment
- [ ] Cloud deployment guide (self-hosted Ollama on GPU)

---

## Architecture Concepts Demonstrated

This project demonstrates:

| Concept | Implementation |
|---------|---------------|
| **RAG** | Retrieval-Augmented Generation pipeline |
| **LLM** | Ollama local inference (llama3.2/mistral) |
| **Vector Database** | ChromaDB with cosine similarity search |
| **Embeddings** | Sentence Transformers (all-MiniLM-L6-v2) |
| **Semantic Search** | Embedding-based document chunk retrieval |
| **Document Intelligence** | PDF/DOCX/TXT parsing with page metadata |
| **FastAPI** | Modern async Python REST API |
| **React** | Component-based frontend with hooks |
| **SQLite** | Lightweight relational DB for metadata |
| **JWT Auth** | Stateless role-based authentication |
| **Local AI** | Fully offline, no external API keys |

---

*Built with Python, FastAPI, React, Ollama, ChromaDB, and Sentence Transformers.*
