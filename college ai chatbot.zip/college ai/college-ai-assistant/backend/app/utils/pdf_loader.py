import pymupdf as fitz  # PyMuPDF (newer import name)
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


def extract_text_from_pdf(file_path: str) -> dict:
    """
    Extract text from a PDF file, preserving page numbers.
    Returns: { "pages": [ {"page_number": 1, "text": "..."} ], "total_pages": N }
    """
    pages = []
    try:
        doc = fitz.open(file_path)
        total_pages = len(doc)
        for page_num in range(total_pages):
            page = doc[page_num]
            text = page.get_text("text")
            text = text.strip()
            if text:
                pages.append({
                    "page_number": page_num + 1,
                    "text": text
                })
        doc.close()
        return {"pages": pages, "total_pages": total_pages}
    except Exception as e:
        logger.error(f"Error extracting PDF text from {file_path}: {e}")
        raise ValueError(f"Failed to extract text from PDF: {str(e)}")
