import httpx
import logging
from typing import Optional, AsyncGenerator
import json

from app.config import settings

logger = logging.getLogger(__name__)


async def check_ollama_health() -> dict:
    """Check if Ollama is running and the configured model is available."""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(f"{settings.OLLAMA_BASE_URL}/api/tags")
            if resp.status_code == 200:
                data = resp.json()
                models = [m["name"] for m in data.get("models", [])]
                model_available = any(
                    settings.OLLAMA_MODEL in m or m.startswith(settings.OLLAMA_MODEL)
                    for m in models
                )
                return {
                    "running": True,
                    "model_available": model_available,
                    "available_models": models,
                    "configured_model": settings.OLLAMA_MODEL
                }
    except httpx.ConnectError:
        return {
            "running": False,
            "model_available": False,
            "error": "Cannot connect to Ollama. Please start Ollama and try again.",
            "configured_model": settings.OLLAMA_MODEL
        }
    except Exception as e:
        return {
            "running": False,
            "model_available": False,
            "error": str(e),
            "configured_model": settings.OLLAMA_MODEL
        }


async def generate_response(
    question: str,
    context: str,
    conversation_history: Optional[list] = None
) -> str:
    """
    Generate a response from Ollama using the RAG prompt.
    Returns the generated text.
    """
    system_prompt = """You are an AI college assistant.

Answer the student's question ONLY using the provided college document context below.

Rules:
- Do NOT invent or assume information not present in the context.
- If the answer cannot be found in the provided context, respond with: "I couldn't find this information in the available college documents. Try asking about academics, exams, attendance, placements, syllabus, events, or other uploaded college information."
- When the answer is found, cite the source document name and page number if available.
- Be concise, clear, and helpful.
- Do not use phrases like "Based on the context" — just answer directly."""

    # Build messages
    messages = [{"role": "system", "content": system_prompt}]

    # Add conversation history (last 4 exchanges max to keep context manageable)
    if conversation_history:
        for msg in conversation_history[-8:]:
            messages.append({"role": msg["role"], "content": msg["content"]})

    # Build the user message with context
    user_message = f"""Retrieved College Document Context:
---
{context}
---

Student Question: {question}"""

    messages.append({"role": "user", "content": user_message})

    try:
        async with httpx.AsyncClient(timeout=settings.OLLAMA_TIMEOUT) as client:
            payload = {
                "model": settings.OLLAMA_MODEL,
                "messages": messages,
                "stream": False,
                "options": {
                    "temperature": 0.1,
                    "top_p": 0.9,
                    "num_ctx": 4096
                }
            }
            resp = await client.post(
                f"{settings.OLLAMA_BASE_URL}/api/chat",
                json=payload
            )
            if resp.status_code == 200:
                data = resp.json()
                return data.get("message", {}).get("content", "").strip()
            else:
                logger.error(f"Ollama returned status {resp.status_code}: {resp.text}")
                raise ValueError(f"Ollama error: {resp.status_code}")
    except httpx.ConnectError:
        raise ConnectionError("Ollama is not running. Please start Ollama with 'ollama serve' and try again.")
    except httpx.TimeoutException:
        raise TimeoutError("Ollama request timed out. The model may be loading. Please try again.")
    except Exception as e:
        if "ConnectError" in str(type(e).__name__) or "connect" in str(e).lower():
            raise ConnectionError("Ollama is not running. Please start Ollama with 'ollama serve' and try again.")
        raise
