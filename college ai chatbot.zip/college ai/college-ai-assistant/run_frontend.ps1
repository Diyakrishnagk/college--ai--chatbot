# run_frontend.ps1
# Double-click OR right-click -> "Run with PowerShell"

$root = "C:\Users\hp\OneDrive\Desktop\college ai\college-ai-assistant\frontend"

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  College AI Assistant - Frontend" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

Set-Location $root

# Install if node_modules missing
if (-not (Test-Path "$root\node_modules")) {
    Write-Host "Installing npm packages (first time)..." -ForegroundColor Yellow
    node "$env:APPDATA\npm\node_modules\npm\bin\npm-cli.js" install
}

# create .env if missing
if (-not (Test-Path "$root\.env")) {
    Copy-Item "$root\.env.example" "$root\.env"
    Write-Host "Created .env" -ForegroundColor Green
}

Write-Host ""
Write-Host "  URL: http://localhost:5173" -ForegroundColor White
Write-Host "  Press Ctrl+C to stop" -ForegroundColor Gray
Write-Host ""

# Run vite directly using node - bypasses npm.ps1 policy issue
$vite = "$root\node_modules\.bin\vite.cmd"
if (Test-Path $vite) {
    & $vite
} else {
    # fallback
    node "$root\node_modules\vite\bin\vite.js"
}
