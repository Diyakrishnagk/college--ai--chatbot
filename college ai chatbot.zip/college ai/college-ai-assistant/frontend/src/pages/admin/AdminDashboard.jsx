import { useEffect, useState } from 'react'
import AdminLayout from '../../layouts/AdminLayout'
import api from '../../services/api'
import {
  FileText, Users, MessageSquare, BarChart3,
  Database, Zap, TrendingUp, RefreshCw
} from 'lucide-react'

function StatCard({ icon: Icon, label, value, color, sub }) {
  return (
    <div className="card p-5 flex items-center gap-4">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${color}`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <div>
        <p className="text-2xl font-bold text-gray-900">{value ?? '—'}</p>
        <p className="text-sm text-gray-500">{label}</p>
        {sub && <p className="text-xs text-gray-400 mt-0.5">{sub}</p>}
      </div>
    </div>
  )
}

export default function AdminDashboard() {
  const [overview, setOverview] = useState(null)
  const [loading, setLoading] = useState(true)
  const [ollamaStatus, setOllamaStatus] = useState(null)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      const [overviewRes, ollamaRes] = await Promise.all([
        api.get('/analytics/overview'),
        api.get('/chat/ollama-status')
      ])
      setOverview(overviewRes.data)
      setOllamaStatus(ollamaRes.data)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  return (
    <AdminLayout>
      <div className="p-6 max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-gray-500 mt-1">System overview and analytics</p>
          </div>
          <button onClick={fetchData} className="btn-secondary flex items-center gap-2 text-sm">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>

        {/* Ollama status banner */}
        {ollamaStatus && (
          <div className={`mb-6 p-4 rounded-xl border ${ollamaStatus.running ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
            <div className="flex items-center gap-3">
              <span className={`w-3 h-3 rounded-full flex-shrink-0 ${ollamaStatus.running ? 'bg-green-500' : 'bg-red-500'}`} />
              <div>
                <p className={`font-medium text-sm ${ollamaStatus.running ? 'text-green-800' : 'text-red-800'}`}>
                  Ollama: {ollamaStatus.running ? `Running — Model: ${ollamaStatus.configured_model}` : 'Not Running'}
                </p>
                {!ollamaStatus.running && (
                  <p className="text-xs text-red-600 mt-0.5">
                    Start Ollama: <code className="bg-red-100 px-1 rounded">ollama serve</code> then pull model: <code className="bg-red-100 px-1 rounded">ollama pull {ollamaStatus.configured_model}</code>
                  </p>
                )}
                {ollamaStatus.running && !ollamaStatus.model_available && (
                  <p className="text-xs text-yellow-700 mt-0.5">
                    Model not downloaded yet. Run: <code className="bg-yellow-100 px-1 rounded">ollama pull {ollamaStatus.configured_model}</code>
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Stats */}
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
            {[1,2,3,4,5,6].map(i => <div key={i} className="h-24 bg-gray-100 rounded-xl animate-pulse" />)}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
            <StatCard icon={FileText} label="Total Documents" value={overview?.total_documents} color="bg-blue-500" />
            <StatCard icon={Users} label="Total Students" value={overview?.total_students} color="bg-green-500" />
            <StatCard icon={MessageSquare} label="Total Questions" value={overview?.total_questions} color="bg-purple-500" sub={`${overview?.questions_today ?? 0} today`} />
            <StatCard icon={BarChart3} label="Conversations" value={overview?.total_conversations} color="bg-orange-500" />
            <StatCard icon={Database} label="Document Chunks" value={overview?.total_chunks} color="bg-indigo-500" sub="Stored in ChromaDB" />
            <StatCard icon={TrendingUp} label="Avg Questions/Conv" value={overview?.avg_questions_per_conversation} color="bg-pink-500" />
          </div>
        )}

        {/* Quick links */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { href: '/admin/upload', label: 'Upload Document', icon: '📤', color: 'bg-blue-50 border-blue-200' },
            { href: '/admin/documents', label: 'Manage Docs', icon: '📁', color: 'bg-green-50 border-green-200' },
            { href: '/admin/analytics', label: 'Analytics', icon: '📊', color: 'bg-purple-50 border-purple-200' },
            { href: '/admin/users', label: 'Users', icon: '👥', color: 'bg-orange-50 border-orange-200' },
          ].map(item => (
            <a key={item.href} href={item.href}
              className={`card p-4 border flex flex-col items-center text-center gap-2 hover:shadow-md transition-shadow ${item.color}`}>
              <span className="text-3xl">{item.icon}</span>
              <span className="text-sm font-medium text-gray-700">{item.label}</span>
            </a>
          ))}
        </div>
      </div>
    </AdminLayout>
  )
}
