from typing import List, Dict, Any
import logging

from app.config import settings

logger = logging.getLogger(__name__)


def build_context_from_chunks(chunks: List[Dict[str, Any]]) -> str:
    """
    Format retrieved chunks into a context string for the LLM.
    Filters by similarity threshold and deduplicates.
    """
    # Filter by similarity threshold
    filtered = [
        c for c in chunks
        if c.get("similarity_score", 0) >= settings.SIMILARITY_THRESHOLD
    ]

    if not filtered:
        return ""

    # Deduplicate by chunk_id
    seen_ids = set()
    unique_chunks = []
    for chunk in filtered:
        cid = chunk.get("chunk_id") or chunk["metadata"].get("chunk_id")
        if cid not in seen_ids:
            seen_ids.add(cid)
            unique_chunks.append(chunk)

    context_parts = []
    for i, chunk in enumerate(unique_chunks, 1):
        meta = chunk["metadata"]
        doc_name = meta.get("document_name", "Unknown Document")
        page = meta.get("page_number", "N/A")
        text = chunk["text"]
        context_parts.append(f"[Source {i}: {doc_name}, Page {page}]\n{text}")

    return "\n\n---\n\n".join(context_parts)


def extract_citations(chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Extract unique citations from retrieved chunks.
    Returns a deduplicated list of source citations.
    """
    filtered = [
        c for c in chunks
        if c.get("similarity_score", 0) >= settings.SIMILARITY_THRESHOLD
    ]

    seen = set()
    citations = []
    for chunk in filtered:
        meta = chunk["metadata"]
        doc_name = meta.get("document_name", "Unknown")
        page = meta.get("page_number")
        doc_id = meta.get("document_id", "")
        key = f"{doc_name}_{page}"
        if key not in seen:
            seen.add(key)
            citations.append({
                "document_name": doc_name,
                "document_id": doc_id,
                "page": page,
                "relevance_score": round(chunk.get("similarity_score", 0), 4),
                "file_type": meta.get("file_type", "")
            })

    # Sort by relevance score descending
    citations.sort(key=lambda x: x["relevance_score"], reverse=True)
    return citations
