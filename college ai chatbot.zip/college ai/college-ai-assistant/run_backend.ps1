# run_backend.ps1
# Double-click this file OR right-click -> "Run with PowerShell"
# No execution policy changes needed - uses full paths directly

$ErrorActionPreference = "Stop"

# ── paths ──────────────────────────────────────────────────────────────────
$root    = "C:\Users\hp\OneDrive\Desktop\college ai\college-ai-assistant\backend"
$python  = "$root\.venv\Scripts\python.exe"
$uvicorn = "$root\.venv\Scripts\uvicorn.exe"

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  College AI Assistant - Backend" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# ── check venv exists ──────────────────────────────────────────────────────
if (-not (Test-Path $python)) {
    Write-Host "ERROR: Virtual environment not found." -ForegroundColor Red
    Write-Host "Creating it now..." -ForegroundColor Yellow
    Set-Location $root
    python -m venv .venv
    $python  = "$root\.venv\Scripts\python.exe"
    $uvicorn = "$root\.venv\Scripts\uvicorn.exe"
}

# ── install packages ───────────────────────────────────────────────────────
Write-Host "Step 1/3 - Checking packages..." -ForegroundColor Yellow
& $python -m pip install --quiet bcrypt==4.2.1 2>$null
& $python -m pip install --quiet fastapi "uvicorn[standard]" python-multipart pydantic pydantic-settings "pydantic[email]" sqlalchemy "passlib[bcrypt]" "python-jose[cryptography]" PyMuPDF python-docx sentence-transformers chromadb httpx python-dotenv 2>$null
Write-Host "  Packages OK" -ForegroundColor Green

# ── create .env if missing ─────────────────────────────────────────────────
Write-Host "Step 2/3 - Checking .env file..." -ForegroundColor Yellow
if (-not (Test-Path "$root\.env")) {
    Copy-Item "$root\.env.example" "$root\.env"
    Write-Host "  Created .env from .env.example" -ForegroundColor Green
} else {
    Write-Host "  .env exists OK" -ForegroundColor Green
}

# ── kill anything on port 8000 ─────────────────────────────────────────────
Write-Host "Step 3/3 - Checking port 8000..." -ForegroundColor Yellow
$portCheck = netstat -ano | Select-String ":8000 "
if ($portCheck) {
    $pid8000 = ($portCheck -split '\s+')[-1]
    try {
        Stop-Process -Id $pid8000 -Force -ErrorAction SilentlyContinue
        Write-Host "  Cleared old process on port 8000" -ForegroundColor Green
        Start-Sleep -Seconds 1
    } catch {}
} else {
    Write-Host "  Port 8000 is free" -ForegroundColor Green
}

# ── start backend ──────────────────────────────────────────────────────────
Write-Host ""
Write-Host "Starting backend server..." -ForegroundColor Cyan
Write-Host ""
Write-Host "  URL      : http://localhost:8000" -ForegroundColor White
Write-Host "  API Docs : http://localhost:8000/docs" -ForegroundColor White
Write-Host "  Admin    : admin@college.edu / admin123" -ForegroundColor White
Write-Host ""
Write-Host "  Press Ctrl+C to stop" -ForegroundColor Gray
Write-Host ""

Set-Location $root
$env:TRANSFORMERS_OFFLINE = "1"
& $python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
