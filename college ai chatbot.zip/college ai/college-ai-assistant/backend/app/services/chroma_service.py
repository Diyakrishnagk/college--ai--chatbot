import chromadb
from chromadb.config import Settings as ChromaSettings
from typing import List, Dict, Any, Optional
import logging

from app.config import settings
from app.services.embedding_service import generate_embedding, generate_embeddings_batch

logger = logging.getLogger(__name__)

_chroma_client = None
_collection = None
COLLECTION_NAME = "college_documents"


def get_chroma_client():
    global _chroma_client
    if _chroma_client is None:
        _chroma_client = chromadb.PersistentClient(
            path=settings.CHROMA_PERSIST_DIRECTORY,
            settings=ChromaSettings(anonymized_telemetry=False)
        )
        logger.info(f"ChromaDB client initialized at {settings.CHROMA_PERSIST_DIRECTORY}")
    return _chroma_client


def get_collection():
    global _collection
    if _collection is None:
        client = get_chroma_client()
        _collection = client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"}
        )
        logger.info(f"ChromaDB collection '{COLLECTION_NAME}' ready")
    return _collection


def add_chunks_to_chroma(chunks: List[Dict[str, Any]]) -> bool:
    """
    Add document chunks to ChromaDB.
    Each chunk: { "chunk_id": str, "text": str, "metadata": dict }
    """
    if not chunks:
        return True
    try:
        collection = get_collection()
        ids = [c["chunk_id"] for c in chunks]
        texts = [c["text"] for c in chunks]
        metadatas = [c["metadata"] for c in chunks]

        # Generate embeddings in batch
        embeddings = generate_embeddings_batch(texts)

        # Add in batches of 100
        batch_size = 100
        for i in range(0, len(ids), batch_size):
            collection.add(
                ids=ids[i:i + batch_size],
                embeddings=embeddings[i:i + batch_size],
                documents=texts[i:i + batch_size],
                metadatas=metadatas[i:i + batch_size]
            )
        logger.info(f"Added {len(chunks)} chunks to ChromaDB")
        return True
    except Exception as e:
        logger.error(f"Error adding chunks to ChromaDB: {e}")
        raise


def search_similar_chunks(
    query: str,
    top_k: int = None,
    document_ids: Optional[List[str]] = None
) -> List[Dict[str, Any]]:
    """
    Search ChromaDB for the most similar chunks to a query.
    Returns list of results with text, metadata, and distance score.
    """
    top_k = top_k or settings.TOP_K_RESULTS
    try:
        collection = get_collection()

        # Check if collection has any documents
        count = collection.count()
        if count == 0:
            logger.warning("ChromaDB collection is empty")
            return []

        query_embedding = generate_embedding(query)

        where_filter = None
        if document_ids:
            where_filter = {"document_id": {"$in": document_ids}}

        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=min(top_k, count),
            where=where_filter,
            include=["documents", "metadatas", "distances"]
        )

        chunks = []
        if results and results["ids"] and results["ids"][0]:
            for i, chunk_id in enumerate(results["ids"][0]):
                distance = results["distances"][0][i]
                # ChromaDB cosine distance: 0 = identical, 2 = opposite
                # Convert to similarity score 0-1
                similarity = 1 - (distance / 2)

                chunks.append({
                    "chunk_id": chunk_id,
                    "text": results["documents"][0][i],
                    "metadata": results["metadatas"][0][i],
                    "similarity_score": round(similarity, 4),
                    "distance": distance
                })

        return chunks
    except Exception as e:
        logger.error(f"Error searching ChromaDB: {e}")
        raise


def delete_document_chunks(document_id: str) -> bool:
    """Delete all chunks for a given document from ChromaDB."""
    try:
        collection = get_collection()
        results = collection.get(
            where={"document_id": document_id},
            include=["documents"]
        )
        if results["ids"]:
            collection.delete(ids=results["ids"])
            logger.info(f"Deleted {len(results['ids'])} chunks for document {document_id}")
        return True
    except Exception as e:
        logger.error(f"Error deleting document chunks from ChromaDB: {e}")
        raise


def get_collection_stats() -> Dict[str, Any]:
    """Get basic stats about the ChromaDB collection."""
    try:
        collection = get_collection()
        count = collection.count()
        return {"total_chunks": count, "collection_name": COLLECTION_NAME}
    except Exception as e:
        logger.error(f"Error getting ChromaDB stats: {e}")
        return {"total_chunks": 0, "collection_name": COLLECTION_NAME}
