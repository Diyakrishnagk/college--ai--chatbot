import os
import uuid
import logging
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends, UploadFile, File, Form, BackgroundTasks
from sqlalchemy.orm import Session

from app.models.database import get_db, Document, User, AnalyticsEvent, SessionLocal
from app.services.auth_service import get_current_user, require_admin
from app.services.document_service import validate_file, safe_filename, process_document_sync
from app.services.chroma_service import delete_document_chunks
from app.config import settings
import json

router = APIRouter(prefix="/documents", tags=["Documents"])
logger = logging.getLogger(__name__)

DOCUMENT_CATEGORIES = [
    "Academic", "Exams", "Attendance", "Syllabus",
    "Placements", "Events", "Hostel", "Fees", "General", "Other"
]


@router.post("/upload")
async def upload_document(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    category: str = Form(default="General"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Upload and process a college document. Admin only."""
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file provided")

    content = await file.read()
    file_size = len(content)

    try:
        file_type = validate_file(file.filename, file_size)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if category not in DOCUMENT_CATEGORIES:
        category = "General"

    doc_id = str(uuid.uuid4())
    stored_filename = safe_filename(file.filename, doc_id)
    file_path = os.path.join(settings.UPLOAD_DIRECTORY, stored_filename)

    # Save file to disk immediately
    with open(file_path, "wb") as f:
        f.write(content)

    # Create DB record
    document = Document(
        id=doc_id,
        filename=stored_filename,
        original_filename=file.filename,
        category=category,
        file_type=file_type,
        file_size=file_size,
        status="processing",
        uploaded_by=current_user.id
    )
    db.add(document)

    event = AnalyticsEvent(
        event_type="document_uploaded",
        user_id=current_user.id,
        document_id=doc_id,
        event_metadata=json.dumps({"filename": file.filename, "file_type": file_type})
    )
    db.add(event)
    db.commit()

    # Run processing in a background thread — fully synchronous, no asyncio issues
    background_tasks.add_task(_process_in_thread, doc_id, file_path, file_type)

    return {
        "id": doc_id,
        "filename": file.filename,
        "file_type": file_type,
        "file_size": file_size,
        "status": "processing",
        "message": "Document uploaded. Processing started in background."
    }


def _process_in_thread(doc_id: str, file_path: str, file_type: str):
    """
    Background thread processor.
    Uses a fresh DB session and fully synchronous processing.
    No asyncio.new_event_loop() — that was the cause of silent failures.
    """
    db = SessionLocal()
    try:
        process_document_sync(db, doc_id, file_path, file_type)
    except Exception as e:
        logger.error(f"[{doc_id}] Background thread failed: {e}", exc_info=True)
        # Ensure error is written to DB even if process_document_sync didn't catch it
        try:
            doc = db.query(Document).filter(Document.id == doc_id).first()
            if doc and doc.status not in ("ready", "error"):
                doc.status = "error"
                doc.error_message = str(e)[:500]
                db.commit()
        except Exception:
            pass
    finally:
        db.close()


@router.get("")
def list_documents(
    category: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """List all documents. Accessible by all authenticated users."""
    query = db.query(Document)
    if category:
        query = query.filter(Document.category == category)
    documents = query.order_by(Document.uploaded_at.desc()).all()

    return [
        {
            "id": doc.id,
            "filename": doc.original_filename,
            "category": doc.category,
            "file_type": doc.file_type,
            "file_size": doc.file_size,
            "page_count": doc.page_count,
            "chunk_count": doc.chunk_count,
            "status": doc.status,
            "error_message": doc.error_message,
            "uploaded_at": doc.uploaded_at.isoformat()
        }
        for doc in documents
    ]


@router.get("/categories")
def get_categories():
    return {"categories": DOCUMENT_CATEGORIES}


@router.get("/{document_id}")
def get_document(
    document_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    return {
        "id": doc.id,
        "filename": doc.original_filename,
        "stored_filename": doc.filename,
        "category": doc.category,
        "file_type": doc.file_type,
        "file_size": doc.file_size,
        "page_count": doc.page_count,
        "chunk_count": doc.chunk_count,
        "status": doc.status,
        "error_message": doc.error_message,
        "uploaded_at": doc.uploaded_at.isoformat(),
        "updated_at": doc.updated_at.isoformat()
    }


@router.delete("/{document_id}")
def delete_document(
    document_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Delete a document and its vectors. Admin only."""
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    try:
        delete_document_chunks(document_id)
    except Exception as e:
        logger.warning(f"Could not delete ChromaDB chunks for {document_id}: {e}")

    file_path = os.path.join(settings.UPLOAD_DIRECTORY, doc.filename)
    if os.path.exists(file_path):
        os.remove(file_path)

    db.delete(doc)
    db.commit()
    return {"message": "Document deleted successfully"}


@router.post("/{document_id}/reindex")
def reindex_document_endpoint(
    document_id: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Re-index a document. Admin only."""
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    file_path = os.path.join(settings.UPLOAD_DIRECTORY, doc.filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Document file not found on disk")

    # Delete old vectors first
    try:
        delete_document_chunks(document_id)
    except Exception as e:
        logger.warning(f"Could not delete old ChromaDB chunks: {e}")

    doc.status = "processing"
    doc.chunk_count = 0
    doc.error_message = None
    db.commit()

    file_type = doc.file_type
    background_tasks.add_task(_process_in_thread, document_id, file_path, file_type)

    return {"message": "Re-indexing started", "document_id": document_id}
