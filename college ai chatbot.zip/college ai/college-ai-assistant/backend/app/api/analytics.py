from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from datetime import datetime, timedelta, timezone
import json

def _now():
    return datetime.now(timezone.utc).replace(tzinfo=None)

from app.models.database import get_db, User, Document, Conversation, Message, AnalyticsEvent, Feedback
from app.services.auth_service import require_admin
from app.services.chroma_service import get_collection_stats

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("/overview")
def get_overview(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """High-level analytics overview. Admin only."""
    total_docs = db.query(Document).filter(Document.status == "ready").count()
    total_students = db.query(User).filter(User.role == "student").count()
    total_questions = db.query(AnalyticsEvent).filter(AnalyticsEvent.event_type == "question_asked").count()
    total_conversations = db.query(Conversation).count()

    # Today's questions
    today_start = _now().replace(hour=0, minute=0, second=0, microsecond=0)
    questions_today = db.query(AnalyticsEvent).filter(
        AnalyticsEvent.event_type == "question_asked",
        AnalyticsEvent.created_at >= today_start
    ).count()

    # ChromaDB stats
    chroma_stats = get_collection_stats()

    # Avg questions per conversation
    conv_count = db.query(Conversation).count()
    msg_count = db.query(Message).filter(Message.role == "user").count()
    avg_questions = round(msg_count / conv_count, 1) if conv_count > 0 else 0

    return {
        "total_documents": total_docs,
        "total_students": total_students,
        "total_questions": total_questions,
        "total_conversations": total_conversations,
        "total_chunks": chroma_stats.get("total_chunks", 0),
        "questions_today": questions_today,
        "avg_questions_per_conversation": avg_questions
    }


@router.get("/questions")
def get_questions_over_time(
    days: int = 7,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Questions count grouped by day for the past N days."""
    cutoff = _now() - timedelta(days=days)
    events = db.query(AnalyticsEvent).filter(
        AnalyticsEvent.event_type == "question_asked",
        AnalyticsEvent.created_at >= cutoff
    ).all()

    # Group by date
    counts = {}
    for e in events:
        date_key = e.created_at.strftime("%Y-%m-%d")
        counts[date_key] = counts.get(date_key, 0) + 1

    # Fill missing days with 0
    result = []
    for i in range(days - 1, -1, -1):
        day = (_now() - timedelta(days=i)).strftime("%Y-%m-%d")
        result.append({"date": day, "count": counts.get(day, 0)})

    return {"data": result}


@router.get("/documents")
def get_document_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Document usage and status stats."""
    docs = db.query(Document).all()

    by_category = {}
    by_status = {}
    by_type = {}

    for doc in docs:
        by_category[doc.category] = by_category.get(doc.category, 0) + 1
        by_status[doc.status] = by_status.get(doc.status, 0) + 1
        by_type[doc.file_type] = by_type.get(doc.file_type, 0) + 1

    return {
        "total": len(docs),
        "by_category": [{"name": k, "count": v} for k, v in by_category.items()],
        "by_status": [{"name": k, "count": v} for k, v in by_status.items()],
        "by_type": [{"name": k, "count": v} for k, v in by_type.items()],
        "recent_uploads": [
            {
                "id": doc.id,
                "filename": doc.original_filename,
                "uploaded_at": doc.uploaded_at.isoformat(),
                "status": doc.status,
                "chunk_count": doc.chunk_count
            }
            for doc in sorted(docs, key=lambda d: d.uploaded_at, reverse=True)[:5]
        ]
    }


@router.get("/feedback")
def get_feedback_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    thumbs_up = db.query(Feedback).filter(Feedback.rating == 1).count()
    thumbs_down = db.query(Feedback).filter(Feedback.rating == -1).count()
    return {
        "thumbs_up": thumbs_up,
        "thumbs_down": thumbs_down,
        "total": thumbs_up + thumbs_down
    }
