@echo off
title College AI Backend
cd /d "%~dp0backend"

echo ================================================
echo  College AI Assistant - Backend Setup and Start
echo ================================================
echo.

:: Check if venv exists
if not exist ".venv\Scripts\activate.bat" (
    echo [1/4] Creating Python virtual environment...
    python -m venv .venv
    if errorlevel 1 (
        echo ERROR: Could not create venv. Is Python installed?
        pause
        exit /b 1
    )
)

echo [1/4] Activating virtual environment...
call .venv\Scripts\activate.bat

echo [2/4] Installing/verifying Python packages...
pip install bcrypt==4.2.1 --quiet --exists-action i 2>nul
pip install fastapi uvicorn[standard] python-multipart pydantic pydantic-settings "pydantic[email]" sqlalchemy "passlib[bcrypt]" "python-jose[cryptography]" PyMuPDF python-docx sentence-transformers chromadb httpx python-dotenv --quiet
if errorlevel 1 (
    echo ERROR: pip install failed. Check your internet connection.
    pause
    exit /b 1
)

echo [3/4] Checking .env file...
if not exist ".env" (
    echo Creating .env from .env.example...
    copy .env.example .env
)

echo [4/4] Starting backend server...
echo.
echo  Backend:  http://localhost:8000
echo  API Docs: http://localhost:8000/docs
echo  Default admin: admin@college.edu / admin123
echo.
echo  Press Ctrl+C to stop.
echo.

set TRANSFORMERS_OFFLINE=1
uvicorn app.main:app --reload --port 8000

pause
