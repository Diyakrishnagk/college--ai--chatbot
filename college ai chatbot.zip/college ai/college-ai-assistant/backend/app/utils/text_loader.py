import logging

logger = logging.getLogger(__name__)


def extract_text_from_txt(file_path: str) -> dict:
    """
    Extract text from a plain TXT file.
    Returns: { "pages": [ {"page_number": 1, "text": "..."} ], "total_pages": 1 }
    """
    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read().strip()
        pages = [{"page_number": 1, "text": text}] if text else []
        return {"pages": pages, "total_pages": 1}
    except Exception as e:
        logger.error(f"Error reading TXT file {file_path}: {e}")
        raise ValueError(f"Failed to read TXT file: {str(e)}")
