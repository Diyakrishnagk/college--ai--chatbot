import os
from pydantic_settings import BaseSettings
from pydantic import field_validator
from pathlib import Path
from typing import List


class Settings(BaseSettings):
    # Ollama
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama3.2"
    OLLAMA_TIMEOUT: int = 120

    # ChromaDB
    CHROMA_PERSIST_DIRECTORY: str = "./data/chroma"

    # Database
    DATABASE_URL: str = "sqlite:///./college_assistant.db"

    # File uploads
    UPLOAD_DIRECTORY: str = "./data/uploads"
    MAX_FILE_SIZE_MB: int = 20

    # RAG
    TOP_K_RESULTS: int = 5
    SIMILARITY_THRESHOLD: float = 0.35
    CHUNK_SIZE: int = 800
    CHUNK_OVERLAP: int = 150

    # Embeddings
    EMBEDDING_MODEL: str = "all-MiniLM-L6-v2"

    # Auth
    JWT_SECRET_KEY: str = "change-this-secret-key-in-production"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440  # 24 hours

    # CORS
    ALLOWED_ORIGINS: List[str] = ["http://localhost:5173", "http://localhost:3000"]

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()

# Ensure required directories exist
Path(settings.UPLOAD_DIRECTORY).mkdir(parents=True, exist_ok=True)
Path(settings.CHROMA_PERSIST_DIRECTORY).mkdir(parents=True, exist_ok=True)
