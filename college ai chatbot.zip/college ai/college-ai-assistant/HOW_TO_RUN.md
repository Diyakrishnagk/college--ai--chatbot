# How to Run — College AI Assistant
# =====================================
# Python 3.13, Node 24, Ollama 0.34 — Windows 10/11
# All commands use CMD (cmd.exe) to avoid PowerShell policy issues

## VERIFIED ENVIRONMENT
  Python  : 3.13.3
  Node    : 24.20.0
  npm     : 11.19.0
  Ollama  : 0.34.4  (llama3.2 already downloaded)
  bcrypt  : 4.2.1   (MUST stay at this version)

## ─────────────────────────────────────────
## STEP 1 — Install / verify Python packages
## ─────────────────────────────────────────
Open CMD in:  college-ai-assistant\backend

  cd college-ai-assistant\backend

  :: Activate the venv (CMD version — no policy issues)
  .venv\Scripts\activate.bat

  :: Install/repair all packages
  pip install bcrypt==4.2.1 --force-reinstall
  pip install fastapi uvicorn[standard] python-multipart
  pip install pydantic pydantic-settings "pydantic[email]"
  pip install sqlalchemy passlib[bcrypt] "python-jose[cryptography]"
  pip install PyMuPDF python-docx sentence-transformers chromadb
  pip install httpx python-dotenv pytest

  :: Verify
  python -c "import fastapi,chromadb,sentence_transformers,pymupdf; print('ALL OK')"

## ─────────────────────────────────────────
## STEP 2 — Create .env file (backend)
## ─────────────────────────────────────────
  :: Already created. If missing, run:
  copy .env.example .env

## ─────────────────────────────────────────
## STEP 3 — Install frontend packages
## ─────────────────────────────────────────
Open CMD in:  college-ai-assistant\frontend

  cd college-ai-assistant\frontend
  npm install

## ─────────────────────────────────────────
## STEP 4 — Start Ollama
## ─────────────────────────────────────────
Open CMD anywhere:

  ollama serve

  :: In a different CMD window, pull model if not done:
  ollama pull llama3.2

  :: Verify it is running:
  ollama list

## ─────────────────────────────────────────
## STEP 5 — Run the Backend
## ─────────────────────────────────────────
Open a NEW CMD window:

  cd college-ai-assistant\backend
  .venv\Scripts\activate.bat
  uvicorn app.main:app --reload --port 8000

  You should see:
    INFO: Application startup complete.
    INFO: Uvicorn running on http://127.0.0.1:8000

## ─────────────────────────────────────────
## STEP 6 — Run the Frontend
## ─────────────────────────────────────────
Open a NEW CMD window:

  cd college-ai-assistant\frontend
  npm run dev

  You should see:
    VITE v5.x  ready in xxx ms
    Local:   http://localhost:5173/

## ─────────────────────────────────────────
## STEP 7 — Open the App
## ─────────────────────────────────────────
  Browser:   http://localhost:5173
  API docs:  http://localhost:8000/docs

## ─────────────────────────────────────────
## DEFAULT LOGIN CREDENTIALS
## ─────────────────────────────────────────
  Admin email    : admin@college.edu
  Admin password : admin123

  (Students can register at /register)

## ─────────────────────────────────────────
## QUICK TEST AFTER STARTUP
## ─────────────────────────────────────────
  curl http://localhost:8000/
  curl http://localhost:8000/api/health

## ─────────────────────────────────────────
## RUN THE TEST SUITE
## ─────────────────────────────────────────
  cd college-ai-assistant\backend
  .venv\Scripts\activate.bat
  set TRANSFORMERS_OFFLINE=1
  pytest tests/ -v

  Expected: 25 passed

## ─────────────────────────────────────────
## TROUBLESHOOTING
## ─────────────────────────────────────────

  PROBLEM: PowerShell says "running scripts is disabled"
  FIX:     Use cmd.exe instead of PowerShell for ALL commands.
           Open CMD: press Win+R, type cmd, press Enter.

  PROBLEM: "No module named X"
  FIX:     Make sure venv is activated first:
             .venv\Scripts\activate.bat
           Then re-run pip installs from STEP 1.

  PROBLEM: bcrypt / passlib error about __about__
  FIX:     pip install bcrypt==4.2.1 --force-reinstall

  PROBLEM: "Ollama is not running"
  FIX:     Open a CMD and run:  ollama serve
           Keep that window open while using the app.

  PROBLEM: Login as admin returns 401
  FIX:     Delete the old DB and restart backend:
             del college_assistant.db
             uvicorn app.main:app --reload --port 8000

  PROBLEM: Frontend shows blank page
  FIX:     Make sure backend is running on port 8000 first.
           Check browser console for errors.

  PROBLEM: "Address already in use" on port 8000
  FIX:     netstat -ano | findstr :8000
           taskkill /PID <number> /F

  PROBLEM: Sentence transformer downloads slowly on first run
  FIX:     Wait — it only downloads once (~90 MB).
           After that, start with: set TRANSFORMERS_OFFLINE=1
