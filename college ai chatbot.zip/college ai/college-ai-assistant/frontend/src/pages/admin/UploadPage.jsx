import { useState, useCallback } from 'react'
import AdminLayout from '../../layouts/AdminLayout'
import api from '../../services/api'
import toast from 'react-hot-toast'
import { Upload, File, X, CheckCircle, AlertCircle, Loader2, CloudUpload } from 'lucide-react'

const CATEGORIES = ['Academic','Exams','Attendance','Syllabus','Placements','Events','Hostel','Fees','General','Other']

const STEPS = ['Uploading', 'Extracting text', 'Creating chunks', 'Generating embeddings', 'Indexing in ChromaDB', 'Complete']

function ProcessStep({ label, status }) {
  return (
    <div className="flex items-center gap-3">
      {status === 'done' && <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />}
      {status === 'active' && <Loader2 className="w-5 h-5 text-blue-500 animate-spin flex-shrink-0" />}
      {status === 'pending' && <div className="w-5 h-5 rounded-full border-2 border-gray-200 flex-shrink-0" />}
      {status === 'error' && <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />}
      <span className={`text-sm ${status === 'done' ? 'text-green-700' : status === 'active' ? 'text-blue-700 font-medium' : status === 'error' ? 'text-red-700' : 'text-gray-400'}`}>
        {label}
      </span>
    </div>
  )
}

export default function UploadPage() {
  const [file, setFile] = useState(null)
  const [category, setCategory] = useState('General')
  const [dragging, setDragging] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [processingStatus, setProcessingStatus] = useState(null) // null | 'processing' | 'ready' | 'error'
  const [docId, setDocId] = useState(null)
  const [currentStep, setCurrentStep] = useState(-1)
  const [errorMsg, setErrorMsg] = useState(null)

  const handleFile = (f) => {
    const ext = f.name.split('.').pop().toLowerCase()
    if (!['pdf', 'docx', 'txt'].includes(ext)) {
      toast.error('Only PDF, DOCX, and TXT files are supported')
      return
    }
    if (f.size > 20 * 1024 * 1024) {
      toast.error('File must be under 20MB')
      return
    }
    setFile(f)
    setProcessingStatus(null)
    setCurrentStep(-1)
    setErrorMsg(null)
  }

  const onDrop = useCallback(e => {
    e.preventDefault()
    setDragging(false)
    const f = e.dataTransfer.files[0]
    if (f) handleFile(f)
  }, [])

  const handleUpload = async () => {
    if (!file) return
    setUploading(true)
    setCurrentStep(0)
    setProcessingStatus('processing')
    setErrorMsg(null)

    const formData = new FormData()
    formData.append('file', file)
    formData.append('category', category)

    try {
      const res = await api.post('/documents/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      const newDocId = res.data.id
      setDocId(newDocId)
      setCurrentStep(1)

      // Poll document status
      let attempts = 0
      const maxAttempts = 60
      const poll = setInterval(async () => {
        attempts++
        try {
          const docRes = await api.get(`/documents/${newDocId}`)
          const { status } = docRes.data
          if (status === 'extracting') setCurrentStep(1)
          else if (status === 'chunking') setCurrentStep(2)
          else if (status === 'indexing') setCurrentStep(3)
          else if (status === 'ready') {
            clearInterval(poll)
            setCurrentStep(5)
            setProcessingStatus('ready')
            toast.success('Document processed and indexed successfully!')
          } else if (status === 'error') {
            clearInterval(poll)
            setCurrentStep(-1)
            setProcessingStatus('error')
            setErrorMsg(docRes.data.error_message || 'Processing failed')
            toast.error('Document processing failed')
          }
        } catch (e) {
          // ignore transient errors during polling
        }
        if (attempts >= maxAttempts) {
          clearInterval(poll)
          toast.error('Processing timed out. Check document status.')
        }
      }, 2000)

    } catch (err) {
      setProcessingStatus('error')
      setCurrentStep(-1)
      const detail = err.response?.data?.detail || 'Upload failed'
      setErrorMsg(detail)
      toast.error(detail)
    } finally {
      setUploading(false)
    }
  }

  const reset = () => {
    setFile(null)
    setProcessingStatus(null)
    setCurrentStep(-1)
    setErrorMsg(null)
    setDocId(null)
  }

  const stepStatuses = processingStatus === 'ready'
    ? STEPS.map(() => 'done')
    : STEPS.map((_, i) => {
        if (currentStep < 0) return 'pending'
        if (i < currentStep) return 'done'
        if (i === currentStep) return processingStatus === 'error' ? 'error' : 'active'
        return 'pending'
      })

  return (
    <AdminLayout>
      <div className="p-6 max-w-3xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Upload Document</h1>
          <p className="text-gray-500 mt-1">Upload college documents for AI-powered Q&A</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Upload area */}
          <div className="card p-6">
            <h2 className="font-semibold text-gray-900 mb-4">Select File</h2>

            {/* Drop zone */}
            <div
              onDragOver={e => { e.preventDefault(); setDragging(true) }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
              onClick={() => document.getElementById('file-input').click()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
                dragging ? 'border-blue-400 bg-blue-50' : 'border-gray-300 hover:border-blue-300 hover:bg-gray-50'
              }`}
            >
              <CloudUpload className="w-10 h-10 mx-auto mb-3 text-gray-400" />
              <p className="text-sm font-medium text-gray-700">Drag & drop or click to browse</p>
              <p className="text-xs text-gray-400 mt-1">PDF, DOCX, TXT · Max 20MB</p>
              <input id="file-input" type="file" accept=".pdf,.docx,.txt" hidden onChange={e => e.target.files[0] && handleFile(e.target.files[0])} />
            </div>

            {/* Selected file */}
            {file && (
              <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-3">
                <File className="w-5 h-5 text-blue-600 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-blue-800 truncate">{file.name}</p>
                  <p className="text-xs text-blue-600">{(file.size / 1024).toFixed(1)} KB</p>
                </div>
                {!uploading && <button onClick={reset} className="text-blue-400 hover:text-blue-600"><X className="w-4 h-4" /></button>}
              </div>
            )}

            {/* Category */}
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Category</label>
              <select className="input-field" value={category} onChange={e => setCategory(e.target.value)}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            {/* Upload button */}
            <button
              onClick={handleUpload}
              disabled={!file || uploading || processingStatus === 'ready'}
              className="btn-primary w-full mt-4 flex items-center justify-center gap-2"
            >
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              {uploading ? 'Uploading...' : processingStatus === 'ready' ? '✓ Uploaded' : 'Upload & Process'}
            </button>

            {processingStatus === 'ready' && (
              <button onClick={reset} className="btn-secondary w-full mt-2 text-sm">Upload Another Document</button>
            )}
          </div>

          {/* Progress */}
          <div className="card p-6">
            <h2 className="font-semibold text-gray-900 mb-4">Processing Status</h2>
            {processingStatus === null ? (
              <div className="text-center py-8 text-gray-400">
                <Upload className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p className="text-sm">Upload a file to see processing steps</p>
              </div>
            ) : (
              <div className="space-y-4">
                {STEPS.map((step, i) => (
                  <ProcessStep
                    key={i}
                    label={step}
                    status={processingStatus === 'ready' ? 'done' : stepStatuses[i]}
                  />
                ))}
                {errorMsg && (
                  <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700">
                    <strong>Error:</strong> {errorMsg}
                  </div>
                )}
                {processingStatus === 'ready' && (
                  <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-700 font-medium">
                    ✅ Document is ready for Q&A!
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}
