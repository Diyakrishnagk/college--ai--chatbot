import logging
import json
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from app.config import settings
from app.services.chroma_service import search_similar_chunks
from app.services.ollama_service import generate_response
from app.services.citation_service import build_context_from_chunks, extract_citations
from app.models.database import Conversation, Message, AnalyticsEvent
import uuid
from datetime import datetime, timezone

def _now():
    return datetime.now(timezone.utc).replace(tzinfo=None)

logger = logging.getLogger(__name__)


async def answer_question(
    db: Session,
    question: str,
    conversation_id: Optional[str],
    user_id: str
) -> Dict[str, Any]:
    """
    Full RAG pipeline:
    1. Embed question
    2. Search ChromaDB
    3. Build context
    4. Call Ollama
    5. Return answer + citations
    """
    if not question or not question.strip():
        raise ValueError("Question cannot be empty")

    question = question.strip()

    # Retrieve or create conversation
    if conversation_id:
        conversation = db.query(Conversation).filter(
            Conversation.id == conversation_id,
            Conversation.user_id == user_id
        ).first()
        if not conversation:
            raise ValueError("Conversation not found")
    else:
        # Create new conversation with title from the first question
        title = question[:60] + "..." if len(question) > 60 else question
        conversation = Conversation(
            id=str(uuid.uuid4()),
            user_id=user_id,
            title=title
        )
        db.add(conversation)
        db.commit()

    # Get conversation history for context
    history_messages = db.query(Message).filter(
        Message.conversation_id == conversation.id
    ).order_by(Message.created_at).all()

    conversation_history = [
        {"role": m.role, "content": m.content}
        for m in history_messages[-8:]  # last 4 exchanges
    ]

    # Step 1 & 2: Search ChromaDB
    similar_chunks = search_similar_chunks(query=question, top_k=settings.TOP_K_RESULTS)

    # Step 3: Build context and citations
    context = build_context_from_chunks(similar_chunks)
    citations = extract_citations(similar_chunks)

    if not context:
        # No relevant context found above threshold
        answer = (
            "I couldn't find this information in the available college documents. "
            "Try asking about academics, exams, attendance, placements, syllabus, events, "
            "or other uploaded college information."
        )
        citations = []
    else:
        # Step 4: Generate answer from Ollama
        answer = await generate_response(
            question=question,
            context=context,
            conversation_history=conversation_history
        )

    # Step 5: Save messages to DB
    user_msg = Message(
        id=str(uuid.uuid4()),
        conversation_id=conversation.id,
        role="user",
        content=question,
        created_at=_now()
    )
    db.add(user_msg)

    assistant_msg = Message(
        id=str(uuid.uuid4()),
        conversation_id=conversation.id,
        role="assistant",
        content=answer,
        sources=json.dumps(citations),
        created_at=_now()
    )
    db.add(assistant_msg)

    # Update conversation timestamp
    conversation.updated_at = _now()
    if len(history_messages) == 0:
        pass  # title already set above

    db.commit()

    # Log analytics event
    event = AnalyticsEvent(
        event_type="question_asked",
        user_id=user_id,
        conversation_id=conversation.id,
        event_metadata=json.dumps({"question_length": len(question), "sources_count": len(citations)})
    )
    db.add(event)
    db.commit()

    return {
        "answer": answer,
        "sources": citations,
        "conversation_id": conversation.id,
        "message_id": assistant_msg.id
    }
