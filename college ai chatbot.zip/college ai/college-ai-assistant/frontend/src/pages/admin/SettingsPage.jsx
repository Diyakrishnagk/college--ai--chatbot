import { useState } from 'react'
import AdminLayout from '../../layouts/AdminLayout'
import api from '../../services/api'
import toast from 'react-hot-toast'
import { Settings, Save, Loader2, Server } from 'lucide-react'

export default function SettingsPage() {
  const [checking, setChecking] = useState(false)
  const [ollamaStatus, setOllamaStatus] = useState(null)

  const checkOllama = async () => {
    setChecking(true)
    try {
      const res = await api.get('/chat/ollama-status')
      setOllamaStatus(res.data)
    } catch (e) {
      toast.error('Cannot connect to backend')
    } finally {
      setChecking(false)
    }
  }

  const checkSystem = async () => {
    try {
      const res = await api.get('/health')
      toast.success('System health check passed!')
    } catch (e) {
      toast.error('Health check failed')
    }
  }

  return (
    <AdminLayout>
      <div className="p-6 max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Settings</h1>

        <div className="space-y-6">
          {/* Ollama */}
          <div className="card p-6">
            <h2 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Server className="w-5 h-5 text-blue-600" />
              Ollama / LLM Configuration
            </h2>
            <div className="space-y-3 text-sm text-gray-600">
              <p>Configure the Ollama model via <code className="bg-gray-100 px-1.5 py-0.5 rounded text-xs">backend/.env</code></p>
              <div className="bg-gray-50 p-3 rounded-lg font-mono text-xs space-y-1">
                <p>OLLAMA_BASE_URL=http://localhost:11434</p>
                <p>OLLAMA_MODEL=llama3.2</p>
              </div>
              <p className="text-xs text-gray-400">Supported models: llama3.2, mistral, phi3, gemma, llama2</p>
            </div>
            <div className="mt-4 flex gap-3">
              <button onClick={checkOllama} disabled={checking} className="btn-secondary text-sm flex items-center gap-2">
                {checking ? <Loader2 className="w-4 h-4 animate-spin" /> : <Server className="w-4 h-4" />}
                Check Ollama Status
              </button>
            </div>
            {ollamaStatus && (
              <div className={`mt-4 p-3 rounded-lg text-sm ${ollamaStatus.running ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
                {ollamaStatus.running ? (
                  <>
                    ✅ Ollama is running<br />
                    Model: <strong>{ollamaStatus.configured_model}</strong> {ollamaStatus.model_available ? '(available)' : '(not downloaded — run: ollama pull ' + ollamaStatus.configured_model + ')'}<br />
                    Available: {ollamaStatus.available_models?.join(', ') || 'none'}
                  </>
                ) : (
                  <>❌ Ollama not running. Start with: <code className="bg-red-100 px-1 rounded">ollama serve</code></>
                )}
              </div>
            )}
          </div>

          {/* RAG Settings */}
          <div className="card p-6">
            <h2 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Settings className="w-5 h-5 text-purple-600" />
              RAG Settings
            </h2>
            <div className="space-y-2 text-sm text-gray-600">
              <p>Configure in <code className="bg-gray-100 px-1.5 py-0.5 rounded text-xs">backend/.env</code>:</p>
              <div className="bg-gray-50 p-3 rounded-lg font-mono text-xs space-y-1">
                <p>EMBEDDING_MODEL=all-MiniLM-L6-v2</p>
                <p>TOP_K_RESULTS=5</p>
                <p>SIMILARITY_THRESHOLD=0.35</p>
                <p>CHUNK_SIZE=800</p>
                <p>CHUNK_OVERLAP=150</p>
                <p>MAX_FILE_SIZE_MB=20</p>
              </div>
            </div>
          </div>

          {/* System health */}
          <div className="card p-6">
            <h2 className="font-semibold text-gray-900 mb-4">System Health</h2>
            <button onClick={checkSystem} className="btn-primary text-sm">Run Health Check</button>
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}
