import { useEffect, useState } from 'react'
import AdminLayout from '../../layouts/AdminLayout'
import api from '../../services/api'
import toast from 'react-hot-toast'
import { Search, Trash2, RefreshCw, Eye, FileText, Loader2, AlertCircle } from 'lucide-react'

const statusBadge = (status) => {
  const map = {
    ready: 'badge badge-green',
    processing: 'badge badge-yellow',
    extracting: 'badge badge-blue',
    chunking: 'badge badge-blue',
    indexing: 'badge badge-blue',
    error: 'badge badge-red',
  }
  return map[status] || 'badge badge-gray'
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

export default function ManageDocumentsPage() {
  const [documents, setDocuments] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [reindexing, setReindexing] = useState({})
  const [deleting, setDeleting] = useState({})

  const fetchDocuments = async () => {
    setLoading(true)
    try {
      const res = await api.get('/documents')
      setDocuments(res.data)
    } catch (e) {
      toast.error('Failed to load documents')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchDocuments()
    // Poll every 5s to update statuses
    const interval = setInterval(fetchDocuments, 5000)
    return () => clearInterval(interval)
  }, [])

  const handleDelete = async (id, filename) => {
    if (!confirm(`Delete "${filename}"? This cannot be undone.`)) return
    setDeleting(prev => ({ ...prev, [id]: true }))
    try {
      await api.delete(`/documents/${id}`)
      setDocuments(prev => prev.filter(d => d.id !== id))
      toast.success('Document deleted')
    } catch (e) {
      toast.error('Failed to delete document')
    } finally {
      setDeleting(prev => ({ ...prev, [id]: false }))
    }
  }

  const handleReindex = async (id, filename) => {
    setReindexing(prev => ({ ...prev, [id]: true }))
    try {
      await api.post(`/documents/${id}/reindex`)
      toast.success(`Re-indexing started for "${filename}"`)
      setDocuments(prev => prev.map(d => d.id === id ? { ...d, status: 'processing' } : d))
    } catch (e) {
      toast.error('Failed to start re-indexing')
    } finally {
      setReindexing(prev => ({ ...prev, [id]: false }))
    }
  }

  const filtered = documents.filter(d =>
    !search || d.filename.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <AdminLayout>
      <div className="p-6 max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Manage Documents</h1>
            <p className="text-gray-500 mt-1">{documents.length} document{documents.length !== 1 ? 's' : ''} total</p>
          </div>
          <button onClick={fetchDocuments} className="btn-secondary flex items-center gap-2 text-sm">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-6 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input type="text" placeholder="Search documents..." className="input-field pl-9"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        {loading && documents.length === 0 ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="card p-12 text-center">
            <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p className="text-gray-500 font-medium">No documents found</p>
            <a href="/admin/upload" className="text-blue-600 text-sm hover:underline mt-1 block">Upload your first document →</a>
          </div>
        ) : (
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="text-left px-4 py-3 font-medium text-gray-600">Document</th>
                  <th className="text-left px-4 py-3 font-medium text-gray-600">Category</th>
                  <th className="text-left px-4 py-3 font-medium text-gray-600">Size</th>
                  <th className="text-left px-4 py-3 font-medium text-gray-600">Pages</th>
                  <th className="text-left px-4 py-3 font-medium text-gray-600">Chunks</th>
                  <th className="text-left px-4 py-3 font-medium text-gray-600">Status</th>
                  <th className="text-left px-4 py-3 font-medium text-gray-600">Uploaded</th>
                  <th className="text-left px-4 py-3 font-medium text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map(doc => (
                  <tr key={doc.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <span className="text-base">{doc.file_type === 'pdf' ? '📄' : doc.file_type === 'docx' ? '📝' : '📃'}</span>
                        <div>
                          <p className="font-medium text-gray-900 max-w-xs truncate">{doc.filename}</p>
                          <p className="text-xs text-gray-400 uppercase">{doc.file_type}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="badge badge-blue">{doc.category}</span>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{formatBytes(doc.file_size)}</td>
                    <td className="px-4 py-3 text-gray-600">{doc.page_count || '—'}</td>
                    <td className="px-4 py-3 text-gray-600">{doc.chunk_count || '—'}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <span className={statusBadge(doc.status)}>{doc.status}</span>
                        {['processing','extracting','chunking','indexing'].includes(doc.status) && (
                          <Loader2 className="w-3 h-3 animate-spin text-blue-500" />
                        )}
                      </div>
                      {doc.status === 'error' && doc.error_message && (
                        <p className="text-xs text-red-500 mt-1 max-w-xs truncate" title={doc.error_message}>{doc.error_message}</p>
                      )}
                    </td>
                    <td className="px-4 py-3 text-gray-500 text-xs">
                      {new Date(doc.uploaded_at).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleReindex(doc.id, doc.filename)}
                          disabled={reindexing[doc.id] || ['processing','extracting','chunking','indexing'].includes(doc.status)}
                          className="p-1.5 rounded-lg hover:bg-blue-50 text-gray-400 hover:text-blue-600 transition-colors disabled:opacity-40"
                          title="Re-index"
                        >
                          {reindexing[doc.id] ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                        </button>
                        <button
                          onClick={() => handleDelete(doc.id, doc.filename)}
                          disabled={deleting[doc.id]}
                          className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors disabled:opacity-40"
                          title="Delete"
                        >
                          {deleting[doc.id] ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AdminLayout>
  )
}
