import { useEffect, useState } from 'react'
import StudentLayout from '../../layouts/StudentLayout'
import api from '../../services/api'
import { FileText, Search, Filter } from 'lucide-react'

const statusBadge = (status) => {
  const map = {
    ready: 'badge badge-green',
    processing: 'badge badge-yellow',
    error: 'badge badge-red',
    extracting: 'badge badge-blue',
    chunking: 'badge badge-blue',
    indexing: 'badge badge-blue',
  }
  return map[status] || 'badge badge-gray'
}

export default function DocumentsPage() {
  const [documents, setDocuments] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterCat, setFilterCat] = useState('')

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [docRes, catRes] = await Promise.all([
          api.get('/documents'),
          api.get('/documents/categories')
        ])
        setDocuments(docRes.data)
        setCategories(catRes.data.categories)
      } catch (e) {
        console.error(e)
      } finally {
        setLoading(false)
      }
    }
    fetchAll()
  }, [])

  const filtered = documents.filter(d => {
    const matchSearch = !search || d.filename.toLowerCase().includes(search.toLowerCase())
    const matchCat = !filterCat || d.category === filterCat
    return matchSearch && matchCat
  })

  return (
    <StudentLayout>
      <div className="p-6 max-w-5xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">College Documents</h1>
          <p className="text-gray-500 mt-1">Browse available documents you can ask questions about</p>
        </div>

        {/* Filters */}
        <div className="flex gap-3 mb-6">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search documents..."
              className="input-field pl-9"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <select
            className="input-field w-48"
            value={filterCat}
            onChange={e => setFilterCat(e.target.value)}
          >
            <option value="">All Categories</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1,2,3,4].map(i => <div key={i} className="h-24 bg-gray-100 rounded-xl animate-pulse" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="card p-12 text-center">
            <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p className="text-gray-500 font-medium">No documents found</p>
            <p className="text-gray-400 text-sm mt-1">Ask your admin to upload college documents</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filtered.map(doc => (
              <div key={doc.id} className="card p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0 text-lg">
                    {doc.file_type === 'pdf' ? '📄' : doc.file_type === 'docx' ? '📝' : '📃'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 truncate">{doc.filename}</p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className="badge badge-blue">{doc.category}</span>
                      <span className={statusBadge(doc.status)}>{doc.status}</span>
                    </div>
                    <div className="flex gap-4 mt-2 text-xs text-gray-400">
                      {doc.page_count > 0 && <span>{doc.page_count} pages</span>}
                      {doc.chunk_count > 0 && <span>{doc.chunk_count} chunks</span>}
                      <span>{doc.file_type.toUpperCase()}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </StudentLayout>
  )
}
