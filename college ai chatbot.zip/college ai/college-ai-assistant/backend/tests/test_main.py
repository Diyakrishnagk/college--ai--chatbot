"""
Basic tests for the College AI Assistant backend.
Run with: python -m pytest tests/ -v
"""
import os
import sys
import pytest
import tempfile
import warnings
warnings.filterwarnings("ignore")

# Ensure offline mode so embedding model doesn't re-download
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")

# Add backend to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ==============================================================
# Text Extraction Tests
# ==============================================================

def test_txt_loader():
    from app.utils.text_loader import extract_text_from_txt
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
        f.write("Hello from test file.\nThis is line two.")
        fname = f.name
    try:
        result = extract_text_from_txt(fname)
        assert result["total_pages"] == 1
        assert len(result["pages"]) == 1
        assert "Hello" in result["pages"][0]["text"]
    finally:
        os.unlink(fname)


def test_txt_loader_empty():
    from app.utils.text_loader import extract_text_from_txt
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
        f.write("   ")
        fname = f.name
    try:
        result = extract_text_from_txt(fname)
        assert result["pages"] == []
    finally:
        os.unlink(fname)


def test_docx_loader():
    """Test DOCX extraction - creates a minimal in-memory docx."""
    pytest.importorskip("docx")
    from docx import Document
    from app.utils.docx_loader import extract_text_from_docx

    with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f:
        fname = f.name

    doc = Document()
    doc.add_paragraph("DOCX paragraph one.")
    doc.add_paragraph("DOCX paragraph two.")
    doc.save(fname)

    try:
        result = extract_text_from_docx(fname)
        assert result["total_pages"] == 1
        assert "DOCX paragraph one" in result["pages"][0]["text"]
    finally:
        os.unlink(fname)


def test_pdf_loader():
    """Test PDF extraction - creates a minimal PDF with fitz."""
    pytest.importorskip("fitz")
    import fitz
    from app.utils.pdf_loader import extract_text_from_pdf

    with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as f:
        fname = f.name

    doc = fitz.open()
    page = doc.new_page()
    page.insert_text((72, 72), "Test PDF content page one.")
    doc.save(fname)
    doc.close()

    try:
        result = extract_text_from_pdf(fname)
        assert result["total_pages"] == 1
        assert "Test PDF content" in result["pages"][0]["text"]
    finally:
        os.unlink(fname)


# ==============================================================
# Chunking Tests
# ==============================================================

def test_text_chunker_basic():
    from app.utils.text_chunker import split_text_into_chunks, clean_text
    text = "This is a sentence. " * 50
    chunks = split_text_into_chunks(text, chunk_size=200, chunk_overlap=30)
    assert len(chunks) > 1
    for c in chunks:
        assert len(c) > 0


def test_text_chunker_empty():
    from app.utils.text_chunker import split_text_into_chunks
    chunks = split_text_into_chunks("", chunk_size=500, chunk_overlap=50)
    assert chunks == []


def test_clean_text():
    from app.utils.text_chunker import clean_text
    dirty = "Hello   \n\n\n\n  World\x00\x07"
    cleaned = clean_text(dirty)
    assert "\x00" not in cleaned
    assert "\x07" not in cleaned
    assert "Hello" in cleaned


def test_create_chunks_with_metadata():
    from app.utils.text_chunker import create_chunks_with_metadata
    pages = [
        {"page_number": 1, "text": "Attendance must be at least 75%. " * 10},
        {"page_number": 2, "text": "Exams are held in December. " * 10},
    ]
    chunks = create_chunks_with_metadata(pages, "doc123", "test.pdf", "pdf")
    assert len(chunks) > 0
    for c in chunks:
        assert "chunk_id" in c
        assert "text" in c
        assert c["metadata"]["document_id"] == "doc123"
        assert c["metadata"]["document_name"] == "test.pdf"
        assert "page_number" in c["metadata"]


# ==============================================================
# Embedding Tests
# ==============================================================

def test_embedding_generation():
    """Test that embeddings are generated correctly."""
    pytest.importorskip("sentence_transformers")
    from app.services.embedding_service import generate_embedding, generate_embeddings_batch

    emb = generate_embedding("What is the attendance requirement?")
    assert isinstance(emb, list)
    assert len(emb) > 0
    assert all(isinstance(x, float) for x in emb)

    batch = generate_embeddings_batch(["Hello", "World"])
    assert len(batch) == 2
    assert len(batch[0]) == len(emb)


# ==============================================================
# File Validation Tests
# ==============================================================

def test_file_validation_valid():
    from app.services.document_service import validate_file
    result = validate_file("test.pdf", 1024)
    assert result == "pdf"

    result = validate_file("test.docx", 1024)
    assert result == "docx"

    result = validate_file("test.txt", 1024)
    assert result == "txt"


def test_file_validation_invalid_extension():
    from app.services.document_service import validate_file
    with pytest.raises(ValueError, match="Unsupported file type"):
        validate_file("malware.exe", 1024)


def test_file_validation_too_large():
    from app.services.document_service import validate_file
    big = 25 * 1024 * 1024  # 25MB
    with pytest.raises(ValueError, match="exceeds"):
        validate_file("big.pdf", big)


def test_safe_filename():
    from app.services.document_service import safe_filename
    result = safe_filename("My Document (2024).pdf", "abc123")
    assert result.endswith(".pdf")
    assert "abc123" in result
    assert "(" not in result
    assert ")" not in result


# ==============================================================
# Citation Tests
# ==============================================================

def test_extract_citations():
    from app.services.citation_service import extract_citations
    chunks = [
        {
            "chunk_id": "c1",
            "text": "75% attendance required",
            "metadata": {"document_id": "d1", "document_name": "Regs.pdf", "page_number": 5, "file_type": "pdf"},
            "similarity_score": 0.85
        },
        {
            "chunk_id": "c2",
            "text": "Exam schedule details",
            "metadata": {"document_id": "d1", "document_name": "Regs.pdf", "page_number": 5, "file_type": "pdf"},
            "similarity_score": 0.72
        },
        {
            "chunk_id": "c3",
            "text": "Fee structure",
            "metadata": {"document_id": "d2", "document_name": "Fees.pdf", "page_number": 2, "file_type": "pdf"},
            "similarity_score": 0.50
        },
    ]
    citations = extract_citations(chunks)
    # Should deduplicate same doc+page
    assert len(citations) == 2
    assert citations[0]["relevance_score"] >= citations[1]["relevance_score"]


def test_build_context():
    from app.services.citation_service import build_context_from_chunks
    chunks = [
        {
            "chunk_id": "c1",
            "text": "Attendance must be at least 75%.",
            "metadata": {"document_name": "Regs.pdf", "page_number": 5},
            "similarity_score": 0.85
        }
    ]
    context = build_context_from_chunks(chunks)
    assert "Attendance" in context
    assert "Regs.pdf" in context


def test_build_context_below_threshold():
    from app.services.citation_service import build_context_from_chunks
    chunks = [
        {
            "chunk_id": "c1",
            "text": "Some text",
            "metadata": {"document_name": "File.pdf", "page_number": 1},
            "similarity_score": 0.10  # below threshold
        }
    ]
    context = build_context_from_chunks(chunks)
    assert context == ""


# ==============================================================
# Auth Tests
# ==============================================================

def test_password_hashing():
    from app.services.auth_service import hash_password, verify_password
    hashed = hash_password("mypassword123")
    assert hashed != "mypassword123"
    assert verify_password("mypassword123", hashed)
    assert not verify_password("wrongpassword", hashed)


def test_jwt_token():
    from app.services.auth_service import create_access_token, decode_token
    token = create_access_token({"sub": "user123", "role": "student"})
    payload = decode_token(token)
    assert payload is not None
    assert payload["sub"] == "user123"
    assert payload["role"] == "student"


def test_jwt_invalid_token():
    from app.services.auth_service import decode_token
    payload = decode_token("not.a.valid.token")
    assert payload is None


# ==============================================================
# FastAPI endpoint tests
# ==============================================================

def test_root_endpoint():
    from fastapi.testclient import TestClient
    from app.main import app
    client = TestClient(app)
    res = client.get("/")
    assert res.status_code == 200
    assert "College AI Assistant" in res.json()["message"]


def test_health_endpoint():
    from fastapi.testclient import TestClient
    from app.main import app
    client = TestClient(app)
    res = client.get("/api/health")
    assert res.status_code == 200
    assert "status" in res.json()


def test_register_and_login():
    from fastapi.testclient import TestClient
    from app.main import app
    import uuid
    client = TestClient(app)

    email = f"test_{uuid.uuid4().hex[:8]}@test.com"
    # Register
    res = client.post("/api/auth/register", json={
        "name": "Test Student",
        "email": email,
        "password": "testpass123",
        "role": "student"
    })
    assert res.status_code == 201
    assert "access_token" in res.json()

    # Login
    res2 = client.post("/api/auth/login", json={"email": email, "password": "testpass123"})
    assert res2.status_code == 200
    token = res2.json()["access_token"]

    # Get me
    res3 = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert res3.status_code == 200
    assert res3.json()["email"] == email


def test_login_wrong_password():
    from fastapi.testclient import TestClient
    from app.main import app
    client = TestClient(app)
    res = client.post("/api/auth/login", json={"email": "admin@college.edu", "password": "wrongpassword"})
    assert res.status_code == 401


def test_upload_requires_admin():
    """Non-admin users cannot upload documents."""
    from fastapi.testclient import TestClient
    from app.main import app
    import uuid, io
    client = TestClient(app)

    # Register as student
    email = f"student_{uuid.uuid4().hex[:8]}@test.com"
    reg = client.post("/api/auth/register", json={
        "name": "Test Student", "email": email, "password": "pass123", "role": "student"
    })
    token = reg.json()["access_token"]

    # Try to upload
    res = client.post(
        "/api/documents/upload",
        headers={"Authorization": f"Bearer {token}"},
        files={"file": ("test.txt", io.BytesIO(b"hello"), "text/plain")},
        data={"category": "General"}
    )
    assert res.status_code == 403


def test_documents_endpoint():
    from fastapi.testclient import TestClient
    from app.main import app
    client = TestClient(app)

    # Login as admin
    res = client.post("/api/auth/login", json={"email": "admin@college.edu", "password": "admin123"})
    token = res.json()["access_token"]

    # Get documents
    res2 = client.get("/api/documents", headers={"Authorization": f"Bearer {token}"})
    assert res2.status_code == 200
    assert isinstance(res2.json(), list)
