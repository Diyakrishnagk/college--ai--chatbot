import { useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import StudentLayout from '../../layouts/StudentLayout'
import api from '../../services/api'
import toast from 'react-hot-toast'
import { User, Mail, Lock, Loader2, Save } from 'lucide-react'

export default function ProfilePage() {
  const { user, login } = useAuth()
  const [form, setForm] = useState({ name: user?.name || '', password: '', confirmPassword: '' })
  const [saving, setSaving] = useState(false)

  const handleSave = async () => {
    if (form.password && form.password !== form.confirmPassword) {
      toast.error('Passwords do not match')
      return
    }
    setSaving(true)
    try {
      const payload = {}
      if (form.name !== user?.name) payload.name = form.name
      if (form.password) payload.password = form.password

      if (Object.keys(payload).length === 0) {
        toast('No changes to save')
        return
      }
      await api.patch(`/users/${user.id}`, payload)
      const updatedUser = { ...user, name: form.name }
      localStorage.setItem('user', JSON.stringify(updatedUser))
      toast.success('Profile updated!')
      setForm(f => ({ ...f, password: '', confirmPassword: '' }))
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to update profile')
    } finally {
      setSaving(false)
    }
  }

  return (
    <StudentLayout>
      <div className="p-6 max-w-2xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Profile Settings</h1>

        <div className="card p-6 space-y-6">
          {/* Avatar */}
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-blue-600 flex items-center justify-center text-white text-2xl font-bold">
              {user?.name?.charAt(0)?.toUpperCase()}
            </div>
            <div>
              <p className="font-semibold text-gray-900">{user?.name}</p>
              <p className="text-sm text-gray-500">{user?.email}</p>
              <span className="badge badge-blue mt-1 capitalize">{user?.role}</span>
            </div>
          </div>

          <hr />

          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5 flex items-center gap-2">
              <User className="w-4 h-4" /> Full Name
            </label>
            <input
              type="text"
              className="input-field"
              value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
            />
          </div>

          {/* Email (readonly) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5 flex items-center gap-2">
              <Mail className="w-4 h-4" /> Email Address
            </label>
            <input type="email" className="input-field bg-gray-50" value={user?.email} disabled />
            <p className="text-xs text-gray-400 mt-1">Email cannot be changed</p>
          </div>

          <hr />
          <p className="text-sm font-medium text-gray-700 flex items-center gap-2">
            <Lock className="w-4 h-4" /> Change Password <span className="text-gray-400 font-normal">(leave blank to keep current)</span>
          </p>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">New Password</label>
            <input
              type="password"
              className="input-field"
              placeholder="At least 6 characters"
              value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Confirm Password</label>
            <input
              type="password"
              className="input-field"
              placeholder="Repeat new password"
              value={form.confirmPassword}
              onChange={e => setForm({ ...form, confirmPassword: e.target.value })}
            />
          </div>

          <button onClick={handleSave} disabled={saving} className="btn-primary flex items-center gap-2">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>
    </StudentLayout>
  )
}
