import logging
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.models.database import create_tables, SessionLocal, User
from app.services.auth_service import hash_password
from app.api import auth, chat, documents, analytics, users

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)


def seed_default_admin():
    """Create the default admin account if no admin exists yet."""
    db = SessionLocal()
    try:
        admin = db.query(User).filter(User.role == "admin").first()
        if not admin:
            admin_user = User(
                id=str(uuid.uuid4()),
                name="Admin",
                email="admin@college.edu",
                password_hash=hash_password("admin123"),
                role="admin"
            )
            db.add(admin_user)
            db.commit()
            logger.info("Default admin created: admin@college.edu / admin123")
    except Exception as e:
        logger.warning(f"Could not seed admin: {e}")
    finally:
        db.close()


# Always ensure tables + admin exist at import time (handles TestClient & uvicorn start)
create_tables()
seed_default_admin()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events."""
    logger.info("Starting College AI Assistant backend...")
    create_tables()
    seed_default_admin()
    logger.info("Backend ready!")
    yield
    logger.info("Backend shutting down...")


app = FastAPI(
    title="College AI Assistant API",
    description="AI-powered college assistant using RAG, Ollama, and ChromaDB",
    version="1.0.0",
    lifespan=lifespan
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# Register routers
app.include_router(auth.router, prefix="/api")
app.include_router(chat.router, prefix="/api")
app.include_router(documents.router, prefix="/api")
app.include_router(analytics.router, prefix="/api")
app.include_router(users.router, prefix="/api")


@app.get("/")
def root():
    return {
        "message": "College AI Assistant API",
        "version": "1.0.0",
        "docs": "/docs"
    }


@app.get("/api/health")
async def health():
    from app.services.ollama_service import check_ollama_health
    from app.services.chroma_service import get_collection_stats
    ollama = await check_ollama_health()
    chroma = get_collection_stats()
    return {
        "status": "ok",
        "ollama": ollama,
        "chroma": chroma
    }
