import sys, importlib
packages = [
    'fastapi', 'uvicorn', 'pydantic', 'pydantic_settings',
    'sqlalchemy', 'passlib', 'jose', 'pymupdf',
    'docx', 'sentence_transformers', 'chromadb', 'httpx', 'dotenv', 'bcrypt'
]
all_ok = True
for p in packages:
    try:
        m = importlib.import_module(p)
        v = getattr(m, '__version__', 'installed')
        print(f"  OK  {p:<25} {v}")
    except Exception as e:
        print(f"  MISSING  {p}: {e}")
        all_ok = False

if all_ok:
    print("\nALL PACKAGES OK — ready to start backend")
else:
    print("\nSOME PACKAGES MISSING — run: pip install -r requirements.txt")
    sys.exit(1)
