import { useEffect, useState } from 'react'
import AdminLayout from '../../layouts/AdminLayout'
import api from '../../services/api'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts'
import { RefreshCw, TrendingUp, FileText, MessageSquare, ThumbsUp, ThumbsDown } from 'lucide-react'

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4']

export default function AnalyticsPage() {
  const [overview, setOverview] = useState(null)
  const [questionsData, setQuestionsData] = useState([])
  const [docStats, setDocStats] = useState(null)
  const [feedback, setFeedback] = useState(null)
  const [loading, setLoading] = useState(true)

  const fetchAll = async () => {
    setLoading(true)
    try {
      const [ov, qd, ds, fb] = await Promise.all([
        api.get('/analytics/overview'),
        api.get('/analytics/questions?days=7'),
        api.get('/analytics/documents'),
        api.get('/analytics/feedback')
      ])
      setOverview(ov.data)
      setQuestionsData(qd.data.data)
      setDocStats(ds.data)
      setFeedback(fb.data)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchAll() }, [])

  if (loading) return (
    <AdminLayout>
      <div className="flex items-center justify-center h-full py-24">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    </AdminLayout>
  )

  return (
    <AdminLayout>
      <div className="p-6 max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
            <p className="text-gray-500 mt-1">System usage and insights</p>
          </div>
          <button onClick={fetchAll} className="btn-secondary flex items-center gap-2 text-sm">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>

        {/* KPI row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Questions', value: overview?.total_questions, icon: MessageSquare, color: 'text-blue-600 bg-blue-50' },
            { label: 'Questions Today', value: overview?.questions_today, icon: TrendingUp, color: 'text-green-600 bg-green-50' },
            { label: 'Documents Ready', value: overview?.total_documents, icon: FileText, color: 'text-purple-600 bg-purple-50' },
            { label: 'Avg Q/Conversation', value: overview?.avg_questions_per_conversation, icon: BarChart, color: 'text-orange-600 bg-orange-50' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="card p-4">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${color}`}>
                <Icon className="w-4 h-4" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{value ?? 0}</p>
              <p className="text-xs text-gray-500 mt-0.5">{label}</p>
            </div>
          ))}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {/* Questions over time */}
          <div className="card p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Questions — Last 7 Days</h3>
            {questionsData.length > 0 ? (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={questionsData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={d => d.slice(5)} />
                  <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                  <Tooltip formatter={(v) => [v, 'Questions']} />
                  <Bar dataKey="count" fill="#3b82f6" radius={[4,4,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <p className="text-sm text-gray-400 text-center py-12">No data yet</p>}
          </div>

          {/* Documents by category */}
          <div className="card p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Documents by Category</h3>
            {docStats?.by_category?.length > 0 ? (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={docStats.by_category} dataKey="count" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({ name, value }) => `${name}: ${value}`} labelLine={false}>
                    {docStats.by_category.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : <p className="text-sm text-gray-400 text-center py-12">No documents yet</p>}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Feedback */}
          <div className="card p-5">
            <h3 className="font-semibold text-gray-900 mb-4">User Feedback</h3>
            {feedback?.total > 0 ? (
              <div className="space-y-3">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 text-green-600">
                    <ThumbsUp className="w-5 h-5" />
                    <span className="font-bold text-2xl">{feedback.thumbs_up}</span>
                  </div>
                  <span className="text-gray-300">|</span>
                  <div className="flex items-center gap-2 text-red-500">
                    <ThumbsDown className="w-5 h-5" />
                    <span className="font-bold text-2xl">{feedback.thumbs_down}</span>
                  </div>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
                  <div
                    className="bg-green-500 h-3 rounded-full"
                    style={{ width: `${(feedback.thumbs_up / feedback.total * 100).toFixed(0)}%` }}
                  />
                </div>
                <p className="text-sm text-gray-500">
                  {((feedback.thumbs_up / feedback.total) * 100).toFixed(0)}% positive out of {feedback.total} ratings
                </p>
              </div>
            ) : <p className="text-sm text-gray-400 text-center py-8">No feedback received yet</p>}
          </div>

          {/* Recent uploads */}
          <div className="card p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Recent Documents</h3>
            {docStats?.recent_uploads?.length > 0 ? (
              <div className="space-y-3">
                {docStats.recent_uploads.map(doc => (
                  <div key={doc.id} className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center text-sm flex-shrink-0">📄</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 truncate">{doc.filename}</p>
                      <p className="text-xs text-gray-400">{doc.chunk_count} chunks · {new Date(doc.uploaded_at).toLocaleDateString()}</p>
                    </div>
                    <span className={`badge ${doc.status === 'ready' ? 'badge-green' : 'badge-yellow'}`}>{doc.status}</span>
                  </div>
                ))}
              </div>
            ) : <p className="text-sm text-gray-400 text-center py-8">No documents yet</p>}
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}
