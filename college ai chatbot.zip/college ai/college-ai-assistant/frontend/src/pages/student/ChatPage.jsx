import { useState, useEffect, useRef, useCallback } from 'react'
import { useParams, useLocation, useNavigate } from 'react-router-dom'
import StudentLayout from '../../layouts/StudentLayout'
import api from '../../services/api'
import toast from 'react-hot-toast'
import {
  Send, Plus, MessageSquare, Copy, RefreshCw,
  ThumbsUp, ThumbsDown, Trash2, FileText, ChevronDown,
  Bot, User, Loader2, AlertCircle, Edit2, Check
} from 'lucide-react'

function TypingIndicator() {
  return (
    <div className="flex items-end gap-3 message-enter">
      <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
        <Bot className="w-4 h-4 text-white" />
      </div>
      <div className="bg-white border border-gray-200 rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm">
        <div className="flex gap-1 items-center h-5">
          <div className="typing-dot" />
          <div className="typing-dot" />
          <div className="typing-dot" />
        </div>
      </div>
    </div>
  )
}

function SourceBadge({ source }) {
  const page = source.page ? ` — Page ${source.page}` : ''
  const score = source.relevance_score ? ` (${(source.relevance_score * 100).toFixed(0)}%)` : ''
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-medium border border-blue-200">
      <FileText className="w-3 h-3" />
      {source.document_name}{page}{score}
    </span>
  )
}

function MessageBubble({ msg, onFeedback, onCopy }) {
  const isUser = msg.role === 'user'
  const [feedbackGiven, setFeedbackGiven] = useState(null)
  const [copying, setCopying] = useState(false)

  const handleCopy = () => {
    navigator.clipboard.writeText(msg.content)
    setCopying(true)
    setTimeout(() => setCopying(false), 1500)
    onCopy?.()
  }

  const handleFeedback = async (rating) => {
    if (feedbackGiven) return
    setFeedbackGiven(rating)
    await onFeedback(msg.id, rating)
  }

  if (isUser) {
    return (
      <div className="flex items-end gap-3 justify-end message-enter">
        <div className="max-w-xl bg-blue-600 text-white rounded-2xl rounded-br-sm px-4 py-3 shadow-sm">
          <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
        </div>
        <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center flex-shrink-0">
          <User className="w-4 h-4 text-gray-600" />
        </div>
      </div>
    )
  }

  return (
    <div className="flex items-start gap-3 message-enter">
      <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0 mt-1">
        <Bot className="w-4 h-4 text-white" />
      </div>
      <div className="max-w-2xl flex-1">
        <div className="bg-white border border-gray-200 rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm">
          <p className="text-sm leading-relaxed text-gray-800 whitespace-pre-wrap">{msg.content}</p>
        </div>

        {/* Sources */}
        {msg.sources && msg.sources.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1.5">
            {msg.sources.map((s, i) => <SourceBadge key={i} source={s} />)}
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-2 mt-2 ml-1">
          <button onClick={handleCopy} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors" title="Copy">
            {copying ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => handleFeedback(1)}
            className={`p-1.5 rounded-lg transition-colors ${feedbackGiven === 1 ? 'text-green-600 bg-green-50' : 'hover:bg-gray-100 text-gray-400 hover:text-gray-600'}`}
            title="Helpful"
          >
            <ThumbsUp className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => handleFeedback(-1)}
            className={`p-1.5 rounded-lg transition-colors ${feedbackGiven === -1 ? 'text-red-600 bg-red-50' : 'hover:bg-gray-100 text-gray-400 hover:text-gray-600'}`}
            title="Not helpful"
          >
            <ThumbsDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  )
}

export default function ChatPage() {
  const { conversationId } = useParams()
  const location = useLocation()
  const navigate = useNavigate()

  const [conversations, setConversations] = useState([])
  const [messages, setMessages] = useState([])
  const [currentConvId, setCurrentConvId] = useState(conversationId || null)
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [loadingConv, setLoadingConv] = useState(false)
  const [ollamaStatus, setOllamaStatus] = useState(null)
  const [editingTitle, setEditingTitle] = useState(null)
  const [newTitle, setNewTitle] = useState('')
  const messagesEndRef = useRef(null)
  const inputRef = useRef(null)

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [])

  // Load conversations list
  useEffect(() => {
    loadConversations()
    checkOllama()
  }, [])

  // Load specific conversation
  useEffect(() => {
    if (conversationId) {
      setCurrentConvId(conversationId)
      loadConversation(conversationId)
    } else {
      setMessages([])
      setCurrentConvId(null)
    }
  }, [conversationId])

  // Handle initial query from dashboard
  useEffect(() => {
    if (location.state?.initialQuery) {
      setInput(location.state.initialQuery)
      navigate('/chat', { replace: true, state: {} })
      setTimeout(() => inputRef.current?.focus(), 100)
    }
  }, [location.state])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const checkOllama = async () => {
    try {
      const res = await api.get('/chat/ollama-status')
      setOllamaStatus(res.data)
    } catch (e) {
      setOllamaStatus({ running: false, error: 'Cannot check Ollama status' })
    }
  }

  const loadConversations = async () => {
    try {
      const res = await api.get('/chat/conversations')
      setConversations(res.data)
    } catch (e) {
      console.error(e)
    }
  }

  const loadConversation = async (id) => {
    setLoadingConv(true)
    try {
      const res = await api.get(`/chat/conversations/${id}`)
      setMessages(res.data.messages)
    } catch (e) {
      toast.error('Could not load conversation')
    } finally {
      setLoadingConv(false)
    }
  }

  const sendMessage = async () => {
    const q = input.trim()
    if (!q || sending) return

    setInput('')
    setSending(true)

    // Optimistically add user message
    const tempUserMsg = { id: 'temp-user', role: 'user', content: q, sources: [], created_at: new Date().toISOString() }
    setMessages(prev => [...prev, tempUserMsg])

    try {
      const res = await api.post('/chat', {
        question: q,
        conversation_id: currentConvId
      })

      const { answer, sources, conversation_id, message_id } = res.data

      // Update conversation
      if (!currentConvId || currentConvId !== conversation_id) {
        setCurrentConvId(conversation_id)
        navigate(`/chat/${conversation_id}`, { replace: true })
        loadConversations()
      }

      const aiMsg = {
        id: message_id,
        role: 'assistant',
        content: answer,
        sources: sources || [],
        created_at: new Date().toISOString()
      }
      setMessages(prev => [...prev.filter(m => m.id !== 'temp-user'), tempUserMsg, aiMsg])
      loadConversations()
    } catch (err) {
      setMessages(prev => prev.filter(m => m.id !== 'temp-user'))
      const detail = err.response?.data?.detail || 'Failed to get response'
      toast.error(detail)
    } finally {
      setSending(false)
      inputRef.current?.focus()
    }
  }

  const deleteConversation = async (id) => {
    try {
      await api.delete(`/chat/conversations/${id}`)
      setConversations(prev => prev.filter(c => c.id !== id))
      if (currentConvId === id) {
        setCurrentConvId(null)
        setMessages([])
        navigate('/chat')
      }
    } catch (e) {
      toast.error('Failed to delete conversation')
    }
  }

  const submitFeedback = async (messageId, rating) => {
    try {
      await api.post('/chat/feedback', { message_id: messageId, rating })
      toast.success(rating === 1 ? 'Thanks for the feedback!' : 'Feedback recorded')
    } catch (e) {
      // silent
    }
  }

  const saveTitle = async (id) => {
    if (!newTitle.trim()) return
    try {
      await api.patch(`/chat/conversations/${id}`, { title: newTitle })
      setConversations(prev => prev.map(c => c.id === id ? { ...c, title: newTitle } : c))
      setEditingTitle(null)
    } catch (e) {
      toast.error('Failed to rename')
    }
  }

  const newChat = () => {
    setCurrentConvId(null)
    setMessages([])
    navigate('/chat')
  }

  return (
    <StudentLayout>
      <div className="flex h-full">
        {/* Conversations sidebar */}
        <div className="w-72 bg-white border-r border-gray-200 flex flex-col flex-shrink-0">
          <div className="p-4 border-b border-gray-100">
            <button onClick={newChat} className="btn-primary w-full flex items-center justify-center gap-2 text-sm">
              <Plus className="w-4 h-4" />
              New Chat
            </button>
          </div>

          {/* Ollama status */}
          {ollamaStatus && !ollamaStatus.running && (
            <div className="mx-3 mt-3 p-2.5 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-red-700">Ollama not running. Start with <code className="bg-red-100 px-1 rounded">ollama serve</code></p>
              </div>
            </div>
          )}

          <div className="flex-1 overflow-y-auto p-3 space-y-1">
            {conversations.length === 0 ? (
              <p className="text-xs text-gray-400 text-center py-8">No conversations yet</p>
            ) : (
              conversations.map(conv => (
                <div
                  key={conv.id}
                  className={`group flex items-center gap-2 px-3 py-2.5 rounded-lg cursor-pointer transition-colors ${
                    currentConvId === conv.id ? 'bg-blue-50 text-blue-700' : 'hover:bg-gray-50 text-gray-700'
                  }`}
                  onClick={() => navigate(`/chat/${conv.id}`)}
                >
                  <MessageSquare className="w-4 h-4 flex-shrink-0 opacity-60" />
                  {editingTitle === conv.id ? (
                    <input
                      value={newTitle}
                      onChange={e => setNewTitle(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter') saveTitle(conv.id); if (e.key === 'Escape') setEditingTitle(null) }}
                      onClick={e => e.stopPropagation()}
                      className="flex-1 text-xs bg-white border border-blue-300 rounded px-1.5 py-0.5 focus:outline-none"
                      autoFocus
                    />
                  ) : (
                    <span className="flex-1 text-xs truncate">{conv.title}</span>
                  )}
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" onClick={e => e.stopPropagation()}>
                    <button onClick={() => { setEditingTitle(conv.id); setNewTitle(conv.title) }}
                      className="p-1 rounded hover:bg-gray-200 text-gray-400">
                      <Edit2 className="w-3 h-3" />
                    </button>
                    <button onClick={() => deleteConversation(conv.id)}
                      className="p-1 rounded hover:bg-red-100 text-gray-400 hover:text-red-500">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Chat main area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Header */}
          <div className="px-6 py-4 bg-white border-b border-gray-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div>
                <h2 className="font-semibold text-gray-900 text-sm">College AI Assistant</h2>
                <p className="text-xs text-gray-400">
                  {ollamaStatus?.running
                    ? `Model: ${ollamaStatus.configured_model}`
                    : 'Ollama offline'}
                </p>
              </div>
            </div>
            {ollamaStatus?.running && (
              <span className="flex items-center gap-1.5 text-xs text-green-600">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                Online
              </span>
            )}
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {loadingConv ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
              </div>
            ) : messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center py-12">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-4">
                  <Bot className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Ask anything about your college</h3>
                <p className="text-gray-400 text-sm max-w-md">
                  I'll search through uploaded college documents and give you accurate, cited answers.
                </p>
              </div>
            ) : (
              messages.map(msg => (
                <MessageBubble
                  key={msg.id}
                  msg={msg}
                  onFeedback={submitFeedback}
                  onCopy={() => toast.success('Copied to clipboard')}
                />
              ))
            )}
            {sending && <TypingIndicator />}
            <div ref={messagesEndRef} />
          </div>

          {/* Input area */}
          <div className="p-4 bg-white border-t border-gray-200">
            <div className="flex gap-3 items-end">
              <textarea
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault()
                    sendMessage()
                  }
                }}
                placeholder="Ask about exams, attendance, academics, placements..."
                rows={1}
                className="flex-1 px-4 py-3 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none overflow-hidden"
                style={{ minHeight: '48px', maxHeight: '120px' }}
                onInput={e => {
                  e.target.style.height = 'auto'
                  e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px'
                }}
                disabled={sending}
              />
              <button
                onClick={sendMessage}
                disabled={sending || !input.trim()}
                className="w-12 h-12 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl flex items-center justify-center transition-colors flex-shrink-0"
              >
                {sending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
              </button>
            </div>
            <p className="text-xs text-gray-400 mt-2 text-center">
              Press Enter to send · Shift+Enter for new line · Answers sourced from college documents
            </p>
          </div>
        </div>
      </div>
    </StudentLayout>
  )
}
