import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import StudentLayout from '../../layouts/StudentLayout'
import api from '../../services/api'
import {
  MessageSquare, FileText, BookOpen, GraduationCap,
  Calendar, ChevronRight, Zap, Clock, TrendingUp
} from 'lucide-react'

const quickActions = [
  { label: 'Ask about Exams', query: 'What are the exam rules and schedule?', color: 'bg-blue-50 border-blue-200 text-blue-700', icon: '📝' },
  { label: 'Ask about Attendance', query: 'What is the minimum attendance required?', color: 'bg-green-50 border-green-200 text-green-700', icon: '✅' },
  { label: 'Ask about Academics', query: 'What are the academic regulations?', color: 'bg-purple-50 border-purple-200 text-purple-700', icon: '📚' },
  { label: 'Ask about Placements', query: 'What is the placement process?', color: 'bg-orange-50 border-orange-200 text-orange-700', icon: '💼' },
  { label: 'Ask about Events', query: 'What college events are upcoming?', color: 'bg-pink-50 border-pink-200 text-pink-700', icon: '🎉' },
  { label: 'Ask about Fees', query: 'What are the fee payment details?', color: 'bg-yellow-50 border-yellow-200 text-yellow-700', icon: '💰' },
]

export default function StudentDashboard() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [conversations, setConversations] = useState([])
  const [documents, setDocuments] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [convRes, docRes] = await Promise.all([
          api.get('/chat/conversations'),
          api.get('/documents')
        ])
        setConversations(convRes.data.slice(0, 5))
        setDocuments(docRes.data.filter(d => d.status === 'ready').slice(0, 6))
      } catch (e) {
        console.error(e)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const startChat = (query) => {
    navigate('/chat', { state: { initialQuery: query } })
  }

  return (
    <StudentLayout>
      <div className="p-6 max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">
            Welcome back, {user?.name?.split(' ')[0]}! 👋
          </h1>
          <p className="text-gray-500 mt-1">How can I help you today?</p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="card p-4 flex items-center gap-4">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{conversations.length}</p>
              <p className="text-xs text-gray-500">Conversations</p>
            </div>
          </div>
          <div className="card p-4 flex items-center gap-4">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{documents.length}</p>
              <p className="text-xs text-gray-500">Documents Available</p>
            </div>
          </div>
          <div className="card p-4 flex items-center gap-4">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">AI</p>
              <p className="text-xs text-gray-500">Powered by Ollama</p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-500" />
            Quick Questions
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {quickActions.map((action) => (
              <button
                key={action.label}
                onClick={() => startChat(action.query)}
                className={`flex items-center gap-3 p-3 rounded-xl border text-left hover:shadow-sm transition-shadow ${action.color}`}
              >
                <span className="text-xl">{action.icon}</span>
                <span className="text-sm font-medium">{action.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-6">
          {/* Recent Conversations */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-500" />
                Recent Chats
              </h2>
              <Link to="/chat" className="text-sm text-blue-600 hover:underline">View all</Link>
            </div>
            {loading ? (
              <div className="space-y-2">
                {[1,2,3].map(i => <div key={i} className="h-14 bg-gray-100 rounded-lg animate-pulse" />)}
              </div>
            ) : conversations.length === 0 ? (
              <div className="card p-6 text-center text-gray-400">
                <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p className="text-sm">No conversations yet</p>
                <Link to="/chat" className="text-blue-600 text-sm hover:underline mt-1 block">Start chatting →</Link>
              </div>
            ) : (
              <div className="space-y-2">
                {conversations.map(conv => (
                  <Link key={conv.id} to={`/chat/${conv.id}`}
                    className="card p-3 flex items-center gap-3 hover:shadow-md transition-shadow group">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MessageSquare className="w-4 h-4 text-blue-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 truncate">{conv.title}</p>
                      <p className="text-xs text-gray-400">{conv.message_count} messages</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-gray-500" />
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* Available Documents */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <FileText className="w-5 h-5 text-green-500" />
                Documents
              </h2>
              <Link to="/documents" className="text-sm text-blue-600 hover:underline">View all</Link>
            </div>
            {loading ? (
              <div className="space-y-2">
                {[1,2,3].map(i => <div key={i} className="h-14 bg-gray-100 rounded-lg animate-pulse" />)}
              </div>
            ) : documents.length === 0 ? (
              <div className="card p-6 text-center text-gray-400">
                <FileText className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p className="text-sm">No documents available yet</p>
              </div>
            ) : (
              <div className="space-y-2">
                {documents.map(doc => (
                  <div key={doc.id} className="card p-3 flex items-center gap-3">
                    <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0 text-sm">
                      {doc.file_type === 'pdf' ? '📄' : doc.file_type === 'docx' ? '📝' : '📃'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 truncate">{doc.filename}</p>
                      <p className="text-xs text-gray-400">{doc.category} · {doc.page_count} pages</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </StudentLayout>
  )
}
