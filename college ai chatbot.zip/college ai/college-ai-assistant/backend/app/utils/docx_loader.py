from docx import Document
import logging

logger = logging.getLogger(__name__)


def extract_text_from_docx(file_path: str) -> dict:
    """
    Extract text from a DOCX file.
    DOCX does not have native page numbers; paragraphs are grouped into logical sections.
    Returns: { "pages": [ {"page_number": 1, "text": "..."} ], "total_pages": 1 }
    """
    try:
        doc = Document(file_path)
        full_text = []
        for paragraph in doc.paragraphs:
            text = paragraph.text.strip()
            if text:
                full_text.append(text)

        # Also extract text from tables
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    text = cell.text.strip()
                    if text:
                        full_text.append(text)

        combined = "\n".join(full_text)
        pages = [{"page_number": 1, "text": combined}] if combined else []
        return {"pages": pages, "total_pages": 1}
    except Exception as e:
        logger.error(f"Error extracting DOCX text from {file_path}: {e}")
        raise ValueError(f"Failed to extract text from DOCX: {str(e)}")
