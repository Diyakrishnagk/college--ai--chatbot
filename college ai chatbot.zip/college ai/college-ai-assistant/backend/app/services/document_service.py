import os
import uuid
import logging
from pathlib import Path
from sqlalchemy.orm import Session

from app.config import settings
from app.models.database import Document
from app.utils.pdf_loader import extract_text_from_pdf
from app.utils.docx_loader import extract_text_from_docx
from app.utils.text_loader import extract_text_from_txt
from app.utils.text_chunker import create_chunks_with_metadata
from app.services.chroma_service import add_chunks_to_chroma, delete_document_chunks

logger = logging.getLogger(__name__)

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt"}
MAX_FILE_SIZE = settings.MAX_FILE_SIZE_MB * 1024 * 1024  # bytes


def validate_file(filename: str, file_size: int) -> str:
    """Validate file extension and size. Returns file type string."""
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError(f"Unsupported file type '{ext}'. Allowed: PDF, DOCX, TXT")
    if file_size > MAX_FILE_SIZE:
        raise ValueError(f"File size exceeds {settings.MAX_FILE_SIZE_MB}MB limit")
    return ext.lstrip(".")


def safe_filename(filename: str, doc_id: str) -> str:
    """Generate a safe unique filename to prevent path traversal."""
    ext = Path(filename).suffix.lower()
    base = Path(filename).stem
    safe_base = "".join(c if c.isalnum() or c in "-_" else "_" for c in base)
    return f"{doc_id}_{safe_base[:50]}{ext}"


def extract_text(file_path: str, file_type: str) -> dict:
    """Extract text from a document based on its type."""
    if file_type == "pdf":
        return extract_text_from_pdf(file_path)
    elif file_type == "docx":
        return extract_text_from_docx(file_path)
    elif file_type == "txt":
        return extract_text_from_txt(file_path)
    else:
        raise ValueError(f"Unknown file type: {file_type}")


def process_document_sync(db: Session, document_id: str, file_path: str, file_type: str) -> None:
    """
    Synchronous document processing pipeline — safe to call from background threads.
    Steps:
      1. Extract text (with page numbers)
      2. Split into overlapping chunks
      3. Generate embeddings + store in ChromaDB
      4. Update SQLite metadata
    """
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        logger.error(f"Document {document_id} not found in DB")
        return

    try:
        # Step 1 — Extract text
        logger.info(f"[{document_id}] Step 1: Extracting text from {file_type.upper()}")
        doc.status = "extracting"
        db.commit()

        extracted = extract_text(file_path, file_type)
        pages = extracted["pages"]
        total_pages = extracted["total_pages"]

        if not pages:
            raise ValueError("No text could be extracted from this document. "
                             "The file may be image-only or password-protected.")

        logger.info(f"[{document_id}] Extracted {len(pages)} pages from {total_pages} total pages")

        # Step 2 — Chunk
        logger.info(f"[{document_id}] Step 2: Creating text chunks")
        doc.status = "chunking"
        db.commit()

        chunks = create_chunks_with_metadata(
            pages=pages,
            document_id=document_id,
            document_name=doc.original_filename,
            file_type=file_type
        )

        if not chunks:
            raise ValueError("Document produced no text chunks after splitting. "
                             "The document may contain no readable text.")

        logger.info(f"[{document_id}] Created {len(chunks)} chunks")

        # Step 3 — Embed + store in ChromaDB
        logger.info(f"[{document_id}] Step 3: Generating embeddings and storing in ChromaDB")
        doc.status = "indexing"
        db.commit()

        add_chunks_to_chroma(chunks)

        # Step 4 — Done
        doc.page_count = total_pages
        doc.chunk_count = len(chunks)
        doc.status = "ready"
        doc.error_message = None
        db.commit()

        logger.info(f"[{document_id}] Done: {len(chunks)} chunks indexed across {total_pages} pages")

    except Exception as e:
        logger.error(f"[{document_id}] Processing failed: {e}", exc_info=True)
        try:
            doc.status = "error"
            doc.error_message = str(e)[:500]
            db.commit()
        except Exception as db_err:
            logger.error(f"[{document_id}] Could not save error status: {db_err}")
        raise
