import re
import uuid
from typing import List, Dict, Any
from app.config import settings
import logging

logger = logging.getLogger(__name__)


def clean_text(text: str) -> str:
    """Clean extracted text by removing excessive whitespace and garbage characters."""
    # Replace multiple newlines with double newline
    text = re.sub(r'\n{3,}', '\n\n', text)
    # Replace multiple spaces with single space
    text = re.sub(r' {2,}', ' ', text)
    # Remove null bytes and control characters except newlines/tabs
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
    return text.strip()


def split_text_into_chunks(
    text: str,
    chunk_size: int = None,
    chunk_overlap: int = None
) -> List[str]:
    """
    Split text into overlapping chunks by character count.
    Tries to split on sentence/paragraph boundaries.
    """
    chunk_size = chunk_size or settings.CHUNK_SIZE
    chunk_overlap = chunk_overlap or settings.CHUNK_OVERLAP

    if not text or len(text.strip()) == 0:
        return []

    # Split on double newlines (paragraphs) first
    paragraphs = [p.strip() for p in re.split(r'\n\n+', text) if p.strip()]

    chunks = []
    current_chunk = ""

    for para in paragraphs:
        # If a single paragraph is longer than chunk_size, split it further
        if len(para) > chunk_size:
            # Split on sentence boundaries
            sentences = re.split(r'(?<=[.!?])\s+', para)
            for sentence in sentences:
                if len(current_chunk) + len(sentence) + 1 <= chunk_size:
                    current_chunk = (current_chunk + " " + sentence).strip()
                else:
                    if current_chunk:
                        chunks.append(current_chunk)
                    # Handle sentence longer than chunk_size by hard-splitting
                    if len(sentence) > chunk_size:
                        for i in range(0, len(sentence), chunk_size - chunk_overlap):
                            chunks.append(sentence[i:i + chunk_size])
                        current_chunk = sentence[max(0, len(sentence) - chunk_overlap):]
                    else:
                        current_chunk = sentence
        else:
            if len(current_chunk) + len(para) + 2 <= chunk_size:
                current_chunk = (current_chunk + "\n\n" + para).strip()
            else:
                if current_chunk:
                    chunks.append(current_chunk)
                current_chunk = para

    if current_chunk:
        chunks.append(current_chunk)

    # Apply overlap: prepend tail of previous chunk to next chunk
    if chunk_overlap > 0 and len(chunks) > 1:
        overlapped = [chunks[0]]
        for i in range(1, len(chunks)):
            prev_tail = chunks[i - 1][-chunk_overlap:]
            overlapped.append((prev_tail + " " + chunks[i]).strip())
        return overlapped

    return chunks


def create_chunks_with_metadata(
    pages: List[Dict[str, Any]],
    document_id: str,
    document_name: str,
    file_type: str
) -> List[Dict[str, Any]]:
    """
    Given extracted pages, create chunks with metadata.
    Each chunk contains text + metadata dict.
    """
    all_chunks = []

    for page_data in pages:
        page_number = page_data["page_number"]
        raw_text = page_data["text"]
        clean = clean_text(raw_text)

        if not clean:
            continue

        text_chunks = split_text_into_chunks(clean)

        for chunk_text in text_chunks:
            chunk_id = str(uuid.uuid4())
            all_chunks.append({
                "chunk_id": chunk_id,
                "text": chunk_text,
                "metadata": {
                    "document_id": document_id,
                    "document_name": document_name,
                    "page_number": page_number,
                    "chunk_id": chunk_id,
                    "file_type": file_type,
                }
            })

    logger.info(f"Created {len(all_chunks)} chunks for document {document_name}")
    return all_chunks
